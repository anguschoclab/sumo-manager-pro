# Stable Lords — Master Context (Clean Canon v1.3 — Narrative-First Edition)

Date: 2026-01-06  
Status: Canonical, narrative-first, implementation-ready  
Supersedes: Clean Canon v1.2 (Full Verbose)

Purpose:  
This document is the **definitive design bible** for Stable Lords, rewritten to explicitly enforce a **narrative-first presentation philosophy**.  
The simulation remains fully deterministic and numeric internally, but the *player-facing experience* is deliberately **thematic, descriptive, and story-driven**, with **hard numbers shown only where economically necessary**.

If there is a conflict between *numeric transparency* and *narrative readability*, **narrative readability wins** (except for explicit economic ledgers).

---

## 0. Narrative-First Contract (NEW)

### 0.1 Core Rule
Stable Lords is not presented as a spreadsheet.  
It is presented as **a living chronicle of sumo institutions and careers**.

- The engine uses numbers.
- The UI uses *language*.
- The player reasons in *stories and trends*, not raw stats.

> “The truth exists underneath. The player lives on the surface.”

---

### 0.2 Where Numbers Are Allowed
Numbers may be shown **only** in:
- **Economy ledgers** (yen amounts, salaries, debts, runway)
- **Rankings & records** (wins/losses, rank titles)
- **Time** (basho count, days, weeks)

Everywhere else, values must be:
- banded
- comparative
- trend-based
- described in prose

---

### 0.3 Forbidden Numeric Leakage
The following must *never* be shown as raw numbers:
- attributes (strength, balance, stamina)
- fatigue, morale, injury risk
- growth potential
- rivalry heat
- prestige
- governance thresholds
- AI confidence or intent

---

## 1. Core Vision & Pillars (Narrative Clarified)

### Pillar 1 — Authentic Institutions
The world behaves like real sumo:
- tradition-bound
- hierarchical
- conservative
- slow to change
- rich in subtext

Rules exist, but they are **rarely explained directly**. They are inferred through outcomes, commentary, and consequences.

---

### Pillar 2 — Deterministic, Explainable Simulation
Nothing is random.
Everything can be explained *after the fact*.

But the explanation is framed as:
- “He looked heavy-footed late”
- “The stable seems to be losing its edge”
- “Momentum abandoned him at the rope”

—not as equations.

---

### Pillar 3 — Narrative Consumption, Not Narrative Control
The player does not author stories.  
The player **manages an institution**, and the narrative *emerges*.

The game never invents drama.
It remembers it.

---

## 2. Presentation Philosophy by System

### 2.1 Rikishi Attributes (Narrative Bands)

Attributes are described as:
- “overwhelmingly strong”
- “technically refined”
- “still raw”
- “showing wear”
- “dangerous in short exchanges”

Each phrase maps deterministically to an internal band.

The mapping is consistent, but hidden.

---

### 2.2 Fatigue, Form, and Injuries

Instead of numbers, the UI uses:
- body language
- commentary cues
- recovery notes
- trainer observations

Examples:
- “His legs looked heavy today.”
- “He struggled to reset after the initial clash.”
- “Still favoring the knee.”

Exact values remain invisible.

---

### 2.3 Style & Evolution

Style is presented as **identity**, not math:
- “A relentless pusher.”
- “Comfortable on the belt.”
- “Adapting toward control as he ages.”

Style drift is narrated as *career evolution*, not stat change.

---

## 3. Combat & Bout Narrative

### 3.1 Phase Logs as Story Beats
Each bout produces:
- tachiai description
- control shift
- decisive moment
- finish framing

Example:
> “They collided hard, but it was Takamori who gave ground first.  
> Shirogane stayed patient, waited for the opening, and forced him out at the edge.”

The underlying engine is unchanged; only the *voice* matters.

---

### 3.2 Kimarite Presentation
The official kimarite is shown, but:
- accompanied by descriptive flavor
- contextualized (“late”, “counter”, “on the straw”)
- framed as habit (“another classic yorikiri”)

Players learn tendencies through repetition, not tooltips.

---

## 4. Economy (Exception: Numbers Are Explicit)

Economy is the **one place** where numbers are sacred:
- salaries
- kenshō
- debts
- loans
- runway

This is intentional:
- money is the *hard constraint*
- institutions die from cash, not vibes

However, *impact* is still narrated:
- “Supporters are losing faith.”
- “The books are tightening.”
- “This feels unsustainable.”

---

## 5. Rivalries & Institutional Memory

Rivalries are described as:
- “quiet tension”
- “bad blood”
- “unfinished business”
- “a defining feud”

Heat is never shown.

Players understand importance through:
- headline frequency
- commentary tone
- crowd reaction language
- AI behavior shifts

---

## 6. Governance & Scandals (Language First)

Governance is presented formally:
- notices
- warnings
- rulings
- decisions

But severity is conveyed through **language and ceremony**, not meters:
- “The council has taken note…”
- “This matter will not be ignored.”
- “The decision is final.”

---

## 7. Scouting & Fog-of-War (Narrative Intelligence)

Scouting reports read like analysis, not data dumps:
- “Appears vulnerable to lateral movement.”
- “Struggles when forced into prolonged grapples.”
- “Condition seems to dip late in tournaments.”

Confidence is expressed verbally:
- “Early read”
- “Consistent pattern”
- “Well-established tendency”

---

## 8. Career Journals & History (Chronicle Tone)

Journals are written as **career chronicles**, not timelines:
- chapters
- turning points
- rises and declines
- rivalries as arcs

Example:
> “This basho marked the beginning of his long rivalry with Kiyonoumi, a pairing that would define both careers.”

---

## 9. World Tone & Seasonal Flavor

Seasonal tone influences:
- commentary
- injury framing
- crowd descriptions
- fatigue narration

Winter is harsh.  
Summer is grinding.  
Autumn is tense.  
Spring feels hopeful.

No mechanical explanation is given unless necessary.

---

## 10. UI Language Rules (Binding)

- Prefer verbs over adjectives
- Prefer trends over snapshots
- Prefer comparisons over absolutes
- Prefer implication over explanation

If a tooltip explains *why* something happened, it must do so narratively first.

---

## 11. Developer Contract (Important)

Internally:
- numbers are precise
- determinism is strict
- debugging tools may expose truth

Externally:
- the player never sees the machinery
- the illusion of a living world is preserved

Breaking this contract is a design bug.

---

## 12. Canon One-Liners (Expanded)

- “You don’t manage numbers. You manage consequences.”
- “Careers end quietly long before they end officially.”
- “The most dangerous decline is the one you don’t notice.”
- “Money kills stables. Pride kills careers.”

---

End of Clean Canon v1.3 — Narrative-First Edition
