# Stable Lords — Banzuke & Scheduling System v1.0 (Canonical)

Date: 2026-01-06  
Status: Canonical, deterministic, implementation-ready  
Scope: Defines **division structure, rankings (banzuke), match scheduling (torikumi), promotion/demotion rules, and playoff resolution** for Stable Lords.

This system is the **spine of competitive credibility**. All combat, evolution, AI behavior, economy pacing, and narrative cadence depend on it.

---

## 1. Design Goals

The Banzuke & Scheduling System must:

- Reproduce **recognizable sumo structure** without overfitting real-world edge cases
- Be **fully deterministic** given inputs
- Generate **fair but non-optimal** matchmaking
- Create **clear stakes** for every bout
- Produce **stable, inspectable outputs** for UI, AI, and history

> The banzuke is not a leaderboard — it is a social contract enforced by results.

---

## 2. Divisional Structure

### 2.1 Divisions and Sizes

| Division | Abbrev | Slots |
|---|---|---:|
| Yokozuna | Y | Dynamic (0–4) |
| Ozeki | O | 2–4 |
| Sekiwake | S | 2 |
| Komusubi | K | 2 |
| Maegashira | M | 34 (M1–M17 E/W) |
| Juryo | J | 28 (J1–J14 E/W) |
| Makushita | Ms | 120 |
| Sandanme | Sd | 200 |
| Jonidan | Jd | 250 |
| Jonokuchi | Jk | Variable |

Upper divisions (Makuuchi + Juryo) are **strictly sized**.  
Lower divisions are **soft-sized**, allowing overflow.

---

## 3. Rank Encoding & Data Contracts

### 3.1 Rank ID Format

Canonical rank ID string:
```
{Division}{Number}{Side}
```

Examples:
- `M5E`, `M5W`
- `J2W`
- `S1E`
- `Y1`

Notes:
- Yokozuna and Ozeki do not use sides for display but retain internal ordering.
- Internal ordering index always exists for deterministic sorting.

---

### 3.2 Rank Object Schema

```ts
Rank {
  division: DivisionID
  number: number
  side?: "E" | "W"
  orderIndex: number
}
```

---

## 4. Basho Structure

### 4.1 Basho Length
- **15 days** for all divisions
- One bout per day per active rikishi (upper divisions)
- Lower divisions use scheduled subset days

---

## 5. Match Scheduling (Torikumi)

### 5.1 High-Level Principles

Torikumi must:
- Prefer **rank proximity**
- Avoid immediate rematches
- Maximize late-basho stakes
- Respect fatigue and injury constraints

Torikumi is **not** optimized for fairness — it is optimized for legitimacy.

---

### 5.2 Upper Division Scheduling (Makuuchi)

#### Days 1–5: Opening Phase
- Pair by **rank bands** (±2 ranks)
- East/West bias preferred
- No rematches

#### Days 6–10: Sorting Phase
- Pair by **record similarity**
- Rank distance may widen
- Early leaders meet resistance

#### Days 11–14: Contention Phase
- Leaders face leaders
- Direct yusho impact prioritized
- Rank distance allowed if records demand it

#### Day 15: Resolution Day
- Yusho contenders face highest-impact opponent
- Playoff preparation if ties exist

---

### 5.3 Lower Division Scheduling

- Fixed bout count per basho (typically 7)
- Opponents drawn from same division band
- Fewer rematch constraints

---

## 6. Promotion & Demotion System

### 6.1 Core Philosophy

> Promotion and demotion are **results-driven**, not stat-driven.

All movements are:
- deterministic
- rule-based
- stable under replay

---

### 6.2 Score Inputs

For each rikishi:
- wins
- losses
- division
- starting rank
- opponent average rank (strength of schedule)

---

### 6.3 Upper Division Heuristics (Illustrative)

#### Maegashira ↔ Juryo
- 8–7 at M17 → safe
- 7–8 at M16–17 → demotion candidate
- 9–6 at J1–2 → promotion candidate
- Excess candidates resolved by:
  1) wins
  2) opponent strength
  3) prior rank

---

#### Sanyaku Rules
- Sekiwake: 8+ wins → retain
- Komusubi: 8+ wins → retain
- Ozeki promotion:
  - 33 wins over last 3 basho at S/K
- Ozeki demotion:
  - Make-koshi → kadoban
  - Two consecutive make-koshi → demotion

---

#### Yokozuna
- Promotion via explicit criteria (defined elsewhere)
- Never demoted; retirement triggered by performance decline

---

### 6.4 Lower Division Promotion

- Promotion based on win bands and available slots
- Overflow handled by expanding lower divisions temporarily

---

## 7. Rank Reassignment Algorithm (Deterministic)

1. Separate rikishi by division
2. Sort by:
   - division priority
   - wins
   - strength of schedule
   - prior rank
3. Fill slots top-down
4. Assign East/West alternately
5. Resolve conflicts deterministically

This algorithm must produce the **same banzuke every time**.

---

## 8. Playoffs

### 8.1 Yusho Ties

If two or more rikishi tie for best record:
- Single-elimination playoff
- Matchups determined by:
  1) head-to-head
  2) rank
  3) random but seeded order

---

### 8.2 Playoff Scheduling

- Occurs after Day 15
- Fatigue carries over
- Injuries possible

Playoffs are part of basho history.

---

## 9. Output Artifacts

### 9.1 Banzuke Output

For each basho:
- full rank list
- rank changes (Δ)
- promotion/demotion flags

---

### 9.2 Scheduling Output

For each day:
- bout list
- division
- rikishi IDs
- rank context

---

### 9.3 Historical Storage

- Every banzuke stored immutably
- Used by:
  - narrative
  - analytics
  - career journals
  - AI memory

---

## 10. AI Interaction

AI managers:
- plan recruitment and risk based on rank movement
- value promotion bands differently by profile
- react strongly to near-misses (e.g., 7–8 at M17)

AI does **not** influence torikumi directly.

---

## 11. Player UX Rules

- Banzuke always readable as a list
- Rank changes highlighted
- Promotion battles surfaced narratively
- Determinism guaranteed (no “mystery drops”)

---

## 12. Canon One-Liner

> **The banzuke is the backbone of sumo legitimacy — every bout exists to justify the ranks it produces.**

---

End of document.
