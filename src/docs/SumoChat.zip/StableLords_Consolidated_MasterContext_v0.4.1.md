# Stable Lords / SumoGame — Consolidated Master Context (v0.4.1)
Date: 2026-01-06  
Baseline: v0.4.0 synchronized (Persistence, Time, Combat Engine V3, Training Core) + identity growth update  
Status: Ready for Sprint F: Rivalries & Scouting V1.1

> **Intent:** This is the single “paste-into-a-new-chat” context file that describes **what the game is**, **how it simulates**, and **what’s next**.  
> It consolidates prior master context + design bible fragments into one canonical spec.

---

## Table of Contents
1. Core Vision & Pillars  
2. Canonical Tech Stack (Stable Lords Spec v1.0)  
3. Determinism Rules (Deterministic but Divergent)  
4. World Structure  
5. Time, Calendar, Basho Loop  
6. Beya (Stable) System: Counts, Founding, Succession, Closure  
7. Rikishi: Identity, Growth, Style Evolution, Traits  
8. Combat Engine V3: Phase Model + Kimarite Integration  
9. Banzuke (Ranking) System: Hierarchy + Promotion/Demotion  
10. Economy: Kenshō, Prestige, Funds  
11. Rivalries, Seasons, World Events (Sprint F/H targets)  
12. Roadmap (Recalibrated)  
13. Data & Code Contracts (Types + Helper Modules)

---

# 1. Core Vision & Pillars (Canonical)

## Pillar 1 — Authenticity
- Full six-basho annual cycle: **Hatsu, Haru, Natsu, Nagoya, Aki, Kyushu**.
- Real banzuke hierarchy (Yokozuna → Jonokuchi) and realistic match counts.
- Kenshō banners with authentic payout split and retirement funds.

## Pillar 2 — Deterministic Simulation
- Every outcome is repeatable when given the same **World Seed** and event inputs.
- The combat engine is data-driven via the **82 Kimarite registry**.

## Pillar 3 — Narrative-First
- Every bout produces a log suitable for storylets (Ink.js-ready later).
- Systems (rivalries, seasonal tone, scandals, succession) are designed to generate “headlines”.

## Pillar 4 — Always Playable
- Builds must boot locally, be navigable, and save/load reliably.
- Missing features must degrade gracefully (stubbed UI/actions, seeded demo data).

---

# 2. Canonical Tech Stack (Stable Lords Spec v1.0)

**Frontend Core**
- React (Vite), TypeScript
- Zustand + Immer (state)
- Tailwind + Radix UI (layout, dialogs, controls)
- React Router (navigation)
- React Hook Form (configuration flows)

**Simulation Systems**
- Custom TypeScript sim engine
- seedrandom for deterministic outcomes
- Comlink + Web Workers for parallel simulation
- Zod for data validation
- Optional Ink.js for narrative integration

**Persistence & Packaging**
- Dexie.js (IndexedDB saves)
- pako + JSZip (compression/export)
- Versioned migrations (Dexie)
- Vite PWA for offline play

**Audio/Visual Layer**
- howler.js (sound)
- Framer Motion (animation)
- Lucide React (icons)
- Recharts (analytics)
- react-markdown (dynamic text)

**Tooling**
- Vite, ESBuild
- ESLint + Prettier
- Vitest + RTL
- GitHub Actions (builds)

---

# 3. Determinism Rules (Deterministic but Divergent)

**World Seed** drives:
- Initial world generation (beya count, heya distribution, initial rikishi pools)
- Tournament schedules and matchup ordering (when applicable)
- Combat RNG (when seeded per bout)

**Allowed divergence (still deterministic):**
- Different *inputs* (training choices, scouting actions, event triggers) change outcomes.
- Narrative branches are deterministic given the same event stream.

**Hard rule:** no hidden calls to `Date.now()` inside simulation logic once “seeded mode” is active.  
(Using timestamps is acceptable only for debug seeds or “quick sim” outside canonical runs.)

---

# 4. World Structure

## 4.1 Flexible Beya Count
- Initial world spawns **~42 stables**, randomized in the range **39–45**.
- Ongoing world constraint: maintain roughly **35–50** active stables over time.
- This flexibility allows:
  - Retiring rikishi to found/take over a stable.
  - Stables to close when succession fails.

## 4.2 World Entities (High level)
- **Heya (stable)**: roster, oyakata, funds, facilities, reputation.
- **Rikishi**: identity, physical attributes (current + potential), skills, career record, economics.
- **BashoState**: tournament schedule, day progression, standings, results, prizes.
- **WorldState**: seed, time, collections, history.

---

# 5. Time, Calendar, Basho Loop

- 6 basho per in-game year (Index 0–5).
- During **Basho**: time advances by **day** (Day 1–15).
- Between basho (**Interim**): advances by **week**.
- Interim length: **6 weeks** bridging tournaments.
- Simulation time is independent of real time; “shipping/build time” is real time only.

---

# 6. Beya System: Founding, Succession, Closure

## 6.1 Oyakata Eligibility (Hook exists)
A candidate must satisfy:
- **Rank:** at least Sanyaku caliber in career history (design intent), and meets implemented check hook.
- **Age:** ≥ 28  
- **Conduct:** clean (no match-fixing / severe conduct flags)
- **Lineage constraint:** must have access to an elder stock line (kabu/toshiyori) in Governance V1.

## 6.2 Succession Rules (Design + hooks)
Trigger: post-basho review (and on retirement/death events).
1. Build candidate list (internal + external).
2. Score candidates:
   - prestige, recent performance, loyalty, leadership, conduct, finances
3. Select successor if any candidate clears threshold.
4. If no candidate clears threshold → stable closes OR merges (future option).

## 6.3 Closure Rules (Full)
A beya closes if **any** of these hold:
- Oyakata retires/dies **and** there is **no qualified successor**.
- Severe governance sanction (future: scandal, match-fixing, violence) forces dissolution.
- Bankruptcy / insolvency (future), after a grace period and rescue attempts.

## 6.4 Founding New Stables (More Detailed)
A new stable may be founded when:
- A qualified retired rikishi acquires elder stock.
- Governance permits stable creation (world cap not exceeded).
- Initial funding and facilities minimum met (can be modest).
Founding creates:
- new heya entity
- starter facility levels
- recruitment slots + reputation baseline

---

# 7. Rikishi: Identity, Growth, Style Evolution, Traits

## 7.1 Permanent Identity (Revised)
**Permanent:**
- Unique `id` (never changes).
- Unique `shikona` (weighted syllable generation; uniqueness enforced).
- Birth metadata (nationality, origin, etc.) as desired.

**Not permanent (updated design):**
- **Height and weight can evolve** over a career (especially early years).
- **Style can evolve** as a consequence of physical development and skill drift.

## 7.2 Current vs Potential Physique (New Canon)
Every rikishi has:
- `heightCurrentCm`, `weightCurrentKg`
- `heightPotentialCm`, `weightPotentialKg` (cap)
- `growthCurve` parameters (age/growth stage), plus a “fulfillment” factor.

**Fulfillment rule:** not all rikishi reach their potential. Outcomes depend on:
- training intensity and program fit
- injury history
- nutrition/facility quality
- “discipline”/personality traits (if modeled)

## 7.3 Style Evolution (New Canon)
Style is a **current label**, not a birth label:
- `oshi` tends to correlate with rising mass + power + aggression and comfort with distance.
- `yotsu` tends to correlate with grip skill, balance, and comfort in close contact.
- `hybrid` emerges when both pathways remain viable or coaching emphasizes adaptability.

**Update rule (example):** after each basho (or quarterly), recompute a style score from:
- physique deltas (mass/height changes)
- observed move usage (kimarite distribution)
- grip outcomes (belt-dominant frequency)
- coaching emphasis + archetype (soft influence)

Style can drift gradually (avoid abrupt flips), with hysteresis/thresholds.

## 7.4 Dynamic Attributes
- Fatigue (0–100)
- Momentum/form (e.g., -10 to +10)
- Injury status + weeks remaining  
Injury risk scales upward with **mass + fatigue + intensity**.

## 7.5 Tokui-waza (Signature Moves) — now linked to development
- `favoredKimarite` begins empty or lightly seeded.
- After each win, increment usage for the winning kimarite.
- Maintain top 2–3 as “favorites” for UI and for selection weighting.

**Development effect:**  
As physique/style evolves, the favored pool should drift:
- gaining weight/power may increase force-out success → `oshidashi/yorikiri` rise
- agility + lateral movement may raise trips/pulls
- belt skill development pushes throws/twists

---

# 7.6 Tactical Archetypes (Keep 5, Expanded)

> Archetype = behavioral bias layer.  
> Style = technical/strategic label derived from outcomes and attributes.  
> They usually correlate, but do not have to.

### 1) Oshi Specialist (Pusher/Thrusting)
- **Core idea:** wins the match before grips matter.
- **Identity in logs:** “straight-line violence”, relentless pressure, crowd-pleasing push outs.
- **Strength profile:** high power/aggression; mass amplifies forward drive; balance prevents self-collapse.
- **Bout behaviors:** strong tachiai; maintains separation; punishes hesitation.
- **Weakness profile:** vulnerable to lateral disruption and reactive counters (Speedster/Trickster).
- **Kimarite bias:** `force_out`, `push`, `thrust` with `gripNeed: none`.
- **Coaching knobs:** improve balance and footwork to reduce slap-down losses.

### 2) Yotsu Specialist (Belt Fighter)
- **Core idea:** control first, finish second.
- **Identity in logs:** “clinical grappler”, wins the inside war, dominant mawashi narratives.
- **Strength profile:** technique/experience/balance; grip skill compounds over time.
- **Bout behaviors:** may concede tachiai inches to secure grip; thrives in belt-dominant stances.
- **Weakness profile:** if denied grips repeatedly, offense stalls; early tachiai can be a liability.
- **Kimarite bias:** throws/lifts/twists; `gripNeed: belt` with yotsu stances.
- **Coaching knobs:** train entry and grip fighting; add a “plan B” slap/pull to survive no-grip bouts.

### 3) Speedster (Explosive/Evasive)
- **Core idea:** break the opponent’s structure, then cash out quickly.
- **Identity in logs:** “flash”, sudden angle changes, trips, unpredictable repositioning.
- **Strength profile:** speed/agility; lighter mass supports rapid foot placement.
- **Bout behaviors:** high initiative probability; seeks lateral position; can create rear opportunities.
- **Weakness profile:** volatile; if caught square, collapses; fatigue spikes on repeated bursts.
- **Kimarite bias:** trips, evasions, fast slap/pulls; lateral vectors.
- **Coaching knobs:** durability and balance training; teach selective aggression to reduce self-destruction.

### 4) Trickster (Chaos Merchant)
- **Core idea:** weaponize the opponent’s commitment.
- **Identity in logs:** “mind games”, henka threats, bait-and-punish, chaotic finishes.
- **Strength profile:** composure + agility + risk appetite; high counter bonus.
- **Bout behaviors:** invites overextension; chooses reactive techniques; thrives when opponent is linear.
- **Weakness profile:** low direct-force performance; can lose badly if opponent stays disciplined.
- **Kimarite bias:** slap/pulls, trips, “special” opportunistic wins.
- **Coaching knobs:** improve defensive fundamentals; limit overuse of low-percentage moves.

### 5) All-Rounder (Balanced/Adaptive)
- **Core idea:** take what the match gives you.
- **Identity in logs:** “textbook”, efficient and smart, shifts plans mid-bout.
- **Strength profile:** balanced stats; small global synergy bonus; lower volatility than Speedster/Trickster.
- **Bout behaviors:** reads stance/position, selects the best available finish.
- **Weakness profile:** lacks extreme edge; can be outclassed by specialists at their peak.
- **Kimarite bias:** neutral baseline; tends to pick high-frequency finishes that match stance.
- **Coaching knobs:** specialize situationally (anti-oshi toolkit, belt upgrades, etc.).

---

# 8. Combat Engine V3: Phase Model + Kimarite Integration

## 8.1 Phase Model
1. **Tachiai**: determine initiative/advantage from stats + archetype + style + mass.  
2. **Clinch / Grip battle**: set stance (belt-dominant / push-dominant / no-grip / migi-yotsu / hidari-yotsu).  
3. **Momentum ticks**: fatigue and position changes (frontal / lateral / rear), possible advantage recovery.  
4. **Finisher window**: filter 82 kimarite by stance/position/grip and weight them.  
5. **Resolution**: success vs counter, produce narrative log.

## 8.2 How the Kimarite Registry is used
The registry is not just flavor; it is the **action space** for endings.

**Filter pass:**
- remove forfeits
- stance must satisfy `requiredStances`
- position must satisfy `vector` (“rear” only if rear position)
- grip constraints must satisfy `gripNeed`

**Weighting pass (typical):**
- start with `baseWeight`
- add style affinity (oshi/yotsu/hybrid)
- add archetype bonus
- multiply if kimarite class is in archetype preferred classes
- multiply if kimarite is in `favoredKimarite`
- apply stance and position multipliers
- apply rarity dampening (legendary less frequent)

**Counter pass:**
- follower may flip outcome based on balance/experience/technique + archetype counter bonus
- if counter triggers, choose a defensive class subset (throw/trip/slap_pull/twist/evasion)

---

# 9. Banzuke (Ranking) System

## 9.1 Rank Hierarchy (Authentic)
- Makuuchi: Yokozuna, Ozeki, Sekiwake, Komusubi, Maegashira (M1–M17 E/W)
- Juryo (J1–J14 E/W)
- Makushita, Sandanme, Jonidan, Jonokuchi

## 9.2 Kachi-koshi / Make-koshi
- Sekitori (Juryo+): kachi-koshi at **8+ wins** (15 bouts)
- Lower divisions: kachi-koshi at **4+ wins** (7 bouts)

## 9.3 Promotion Notes (Rules of thumb)
- Ozeki: ~33 wins across 3 basho at sanyaku.
- Yokozuna: typically consecutive yusho or equivalent, via deliberation.
- Makushita → Juryo: usually requires high Makushita rank + strong record (7-0 ideal).

---

# 10. Economy: Kenshō, Prestige, Funds

## 10.1 Kenshō
Per banner:
- ¥70,000 total cost basis
- payout (current design):
  - ¥10,000 to stable funds (immediate)
  - ¥50,000 to rikishi retirement fund
  - remainder treated as fees/overhead (narratively consistent)

## 10.2 Prestige
- scalar used to:
  - influence kenshō banners attracted
  - influence rivalry heat and story spotlighting
- prestige decays weekly in Interim.

---

# 11. Rivalries, Seasons, World Events (Targets)

## 11.1 Rivalry Heat (Sprint F)
- Rivalry object between two rikishi:
  - `heat` (0–100), `lastUpdated`, `keyMoments` (log hooks)
- Heat increases on:
  - close matches, upsets, repeated meetings, title races
- Heat decays during Interim.
- Heat modifies:
  - tachiai intensity, risk appetite, narrative tone, and scouting interest.

## 11.2 Scouting (Sprint F)
- “Fog of war” on attributes:
  - some stats hidden until scouted
  - reveal by watching bouts, coach reports, recruitment visits
- Generates “analyst notes” that are also narrative content.

## 11.3 Seasonal Tone (Sprint H)
- Basho has a season (winter/spring/summer/autumn) that flavors:
  - headlines, crowd mood, injuries, travel fatigue, storylets
- Seasonal world events table can tie into succession/governance.

---

# 12. Roadmap (Recalibrated)

**NEXT: Sprint F — Rivalries & Scouting V1.1**
- rivalry heat + decay + UI surfacing
- scouting fog-of-war + reveal mechanics
- hook rivalry into tachiai + commentary

Sprint H/Q — Narrative Hooks & Seasonal Tone  
Sprint I — Governance V1 (kabu availability, full succession, council politics)  
Sprint L/S — FTUE & UI Polish  
Sprint M/T — Analytics & Career Journal

---

# 13. Data & Code Contracts (Types + Helper Modules)

This project is intended to ship with small, well-named TypeScript helpers (no monolith):
- `types.ts`: canonical domain types (Rikishi, Heya, BashoState, WorldState, etc.)
- `banzuke.ts`: rank hierarchy, formatting, kachi-koshi checks, estimate rank change, ozeki kadoban.
- `kimarite.ts`: Option A kimarite registry entries + query helpers (by stance/style/archetype).
- `boutEngineV3.ts`: deterministic multi-phase simulation, produces `BoutResult` + log.

**Important alignment note:**  
The kimarite registry must contain the full 82 official techniques (for the win space). If additional “variant” outcomes exist (otoshi variants, narrative-only endings), they should be treated as *aliases* or *post-processing labels* rather than expanding the official 82 list.

---

End of Consolidated Context v0.4.1
