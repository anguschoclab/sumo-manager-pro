# Stable Lords — NPC Beya Manager AI System v1.0 (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-ready  
Scope: Defines how **NPC-managed beyās** behave over time, including manager personalities, decision logic, adaptation to meta drift, and failure modes. This system applies equally to all AI stables and is deterministic.

This document intentionally excludes per-rikishi training mechanics, which are defined elsewhere.

---

## 1. Design Goals

NPC managers must:
- Feel **consistent and recognizable** over decades
- Be **non-optimal but rational**
- Respond to a changing world without omniscience
- Create **long-term world texture and drama**
- Obey the same constraints as the player

> NPC managers do not solve the game — they live in it.

---

## 2. What an NPC Manager Is

Each AI-run beya has a single **Manager Profile** that governs:
- roster size targets
- recruitment and release behavior
- staff and facility priorities
- financial risk tolerance
- foreign/dual-citizen recruitment
- reaction speed to success, failure, and meta drift

The manager profile is persistent across the beya’s lifetime unless succession systems later replace it.

---

## 3. Manager Profile Template (Core Parameters)

Each manager has deterministic traits (0.0–1.0 unless noted):

### Strategic traits
- **RiskTolerance**
- **Patience**
- **PipelineBias** (many prospects vs few)
- **StarBias** (resource concentration)
- **RecoveryBias**
- **IdentityRigidity**
- **FinanceDiscipline**
- **FacilityAmbition**

### Talent evaluation traits
- **ScoutingConfidence**
- **UpsideChasing**
- **VarianceAversion**
- **Loyalty**

### Foreign policy traits
- **ForeignSlotAggression**
- **DualCitizenPreference**

These values are seeded at world generation and never change.

---

## 4. Canonical Manager Profiles

### 4.1 Talent Factory
- Roster target: 18–25
- PipelineBias: 0.9
- StarBias: 0.3
- RiskTolerance: 0.4
- Patience: 0.6
- IdentityRigidity: 0.4
- FinanceDiscipline: 0.6
- FacilityAmbition: 0.7
- ForeignSlotAggression: 0.3
- DualCitizenPreference: 0.7

**Fantasy:** produces volume, adapts through generations.

---

### 4.2 Star Chaser
- Roster target: 10–14
- PipelineBias: 0.3
- StarBias: 0.9
- RiskTolerance: 0.7
- Patience: 0.3
- IdentityRigidity: 0.3
- FinanceDiscipline: 0.4
- FacilityAmbition: 0.6
- ForeignSlotAggression: 0.7
- DualCitizenPreference: 0.5

**Fantasy:** chases immediate dominance through elite talent.

---

### 4.3 Survivor
- Roster target: 10–16
- PipelineBias: 0.5
- StarBias: 0.4
- RiskTolerance: 0.2
- Patience: 0.8
- IdentityRigidity: 0.5
- FinanceDiscipline: 0.9
- FacilityAmbition: 0.4
- ForeignSlotAggression: 0.1
- DualCitizenPreference: 0.8

**Fantasy:** endures all eras, rarely collapses.

---

### 4.4 Gambler
- Roster target: 14–20
- PipelineBias: 0.6
- StarBias: 0.7
- RiskTolerance: 0.95
- Patience: 0.2
- IdentityRigidity: 0.2
- FinanceDiscipline: 0.2
- FacilityAmbition: 0.8
- ForeignSlotAggression: 0.8
- DualCitizenPreference: 0.4

**Fantasy:** boom-or-bust chaos engine.

---

### 4.5 Traditionalist
- Roster target: 12–18
- PipelineBias: 0.5
- StarBias: 0.5
- RiskTolerance: 0.35
- Patience: 0.7
- IdentityRigidity: 0.9
- FinanceDiscipline: 0.6
- FacilityAmbition: 0.5
- ForeignSlotAggression: 0.15
- DualCitizenPreference: 0.6

**Fantasy:** resists change, defines eras or stagnates.

---

## 5. Manager Quirks (Individual Flavor)

Each manager has 1–2 deterministic quirks:
- Injury Paranoid (+RecoveryBias)
- Prospect Hoarder (+PipelineBias)
- Foreign Talent Believer (+ForeignSlotAggression)
- Facility Maximalist (+FacilityAmbition, −FinanceDiscipline)
- Contrarian (counter-meta bias)

Quirks slightly modify base traits.

---

## 6. Meta Drift System (World-Level)

### 6.1 What the Meta Is
The meta is an emergent snapshot of what is succeeding.

Tracked each basho (top divisions):
- `styleShare` (oshi / yotsu / hybrid)
- `kimariteClassShare` (push, throw, slap-pull, trip, rear)
- `pressureIndex` (inverse avg bout length + shove prevalence)
- `gripIndex` (belt-dominant stance frequency)
- `injuryIndex` (injuries per 100 bouts)

---

### 6.2 Drift Detection
Maintain:
- Short window: last 2 basho
- Long window: last 6 basho

Compute:
```
drift = metaShortAvg − metaLongAvg
```

Only magnitude above threshold is actionable.

---

## 7. AI Adaptation to Meta Drift

AI does not see “the meta” — it reacts to:
- global signals
- its own performance trends

### 7.1 Reaction Lag by Profile

| Profile | Reaction Delay |
|---|---|
| Gambler | 1–2 basho |
| Star Chaser | 1–3 basho |
| Talent Factory | 3–6 basho |
| Survivor | 4–6 basho |
| Traditionalist | 4–8 basho |

---

### 7.2 Confirmation Thresholds

Before adapting:
- drift magnitude must exceed threshold
- AND local performance trend must confirm (except Gambler)

Traditionalist requires strongest confirmation.

---

### 7.3 Adaptation Levers (No Training)

| Lever | Effect |
|---|---|
| Recruitment bias | Select physiques/styles matching or countering meta |
| Facility priority | Invest in facilities that support meta demands |
| Roster sizing | Shrink or expand to handle volatility |
| Foreign slot usage | Chase uniqueness if meta rewards extremes |

---

### 7.4 Adaptation Tables (Examples)

**If pressureIndex rises (fast oshi meta):**
- Star Chaser: recruits power/speed, conditioning focus
- Talent Factory: shifts pipeline toward heavier builds
- Survivor: benefits passively, minimal change
- Traditionalist: may go counter-meta (throws)
- Gambler: extreme oshi or extreme counter

**If gripIndex rises (yotsu meta):**
- Technique facilities valued
- Throw-capable recruits prioritized
- Traditionalist shows strength
- Gambler chases rare technicians

**If injuryIndex rises:**
- Survivor and Talent Factory invest in medical
- Star Chaser risks collapse
- Gambler doubles down or implodes

---

## 8. Counter-Meta Behavior

If:
- one style >55% prevalence
- manager has high IdentityRigidity or Contrarian quirk

Then:
- manager may intentionally pursue counter-meta recruitment

This seeds future reversals.

---

## 9. Foreign & Dual Citizenship Logic (AI)

AI obeys:
- 1 foreign-slot rule
- dual citizens do not consume slot

Decision factors:
- ForeignSlotAggression
- injury tolerance
- facilities readiness
- cash runway

AI reluctant to release foreign-slot wrestlers due to sunk-cost bias.

---

## 10. Weekly AI Decision Loop

Each interim week:
1) Compute solvency runway
2) Check injury load
3) Evaluate roster vs target
4) Apply meta-influenced recruitment bias
5) Consider staff/facility actions
6) Enter austerity or gamble modes if needed

All decisions are deterministic.

---

## 11. Failure Modes (By Design)

- Overreaction to short-term meta (Star Chaser, Gambler)
- Underreaction and stagnation (Traditionalist)
- Pipeline collapse due to neglect
- Foreign-slot deadlock
- Financial ruin

Failure creates narrative, not errors.

---

## 12. Player Perception Rules

Players never see trait numbers, only behavior:
- “That stable always overreacts.”
- “That one never changes.”
- “They keep gambling on foreign giants.”

This is the success condition.

---

## 13. Canon One-Liner

> **NPC managers do not chase the meta perfectly; they interpret it through personality, patience, and bias — and that is what makes the world feel alive.**

---

End of document.
