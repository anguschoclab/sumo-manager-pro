# Stable Lords — Economy & Prestige System v1.0 (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-ready  
Scope: Defines the **complete economic model** for Stable Lords, including kenshō banners, prestige, beya finances, awards impact, retirement funds, and insolvency handling.

This document is the **single source of truth** for money and prestige. All other systems reference it.

---

## 1. Design Goals

The economy must:
- Support **long-horizon planning**, not short-term optimization
- Reward **sporting success, consistency, and legacy**
- Create **real financial pressure** on beya decisions
- Be **deterministic and auditable**
- Scale cleanly over multi-decade simulations
- Integrate tightly with:
  - Banzuke & Basho Awards
  - Beya Management
  - Training
  - NPC Manager AI
  - Governance (future)

> Money is not a score — it is a constraint.

---

## 2. Economic Entities

### 2.1 Actors
- **Rikishi** (earn, save, retire)
- **Beya** (operating budgets)
- **League / JSA** (source of banners, prestige baseline)
- **Sponsors** (abstracted via kenshō)
- **Benefactors / Creditors** (future)

---

## 3. Currency Model

- Single currency: **¥ (yen-equivalent)**
- No inflation by default
- Inflation/deflation controlled by global tuning constants only
- All values deterministic

---

## 4. Income Sources

### 4.1 Kenshō Banners (Primary Variable Income)

**Cadence:** Per bout, resolved immediately after bout.

Each bout may have **0–N kenshō banners** attached.

#### Banner Value
- Base value per banner: **¥70,000**
- Split:
  - 50% to winning rikishi
  - 50% to beya operating fund

#### Banner Count Determination
Banner count is deterministic based on:
- basho prestige
- rikishi prestige
- bout importance (rank, day, contention impact)

Example:
```
bannerCount =
  floor(
    (rikishiPrestige + opponentPrestige + bashoImportance)
    × bannerScalar
  )
```

---

### 4.2 Basho Awards & Trophies

**Cadence:** Basho-end (after playoffs).

Awards do **not** grant direct cash by default.  
They grant **prestige**, which indirectly increases future income.

Optional cash bonuses (tunable):
- Sanshō: ¥200,000 (optional)
- Yusho bonus: ¥500,000 (optional)

Defaults: **prestige-only**.

---

### 4.3 Fixed League Stipends (Optional)

To prevent early collapse:
- Small weekly stipend to all active beya (¥10,000–20,000)
- Tunable or disableable

---

## 5. Prestige System

### 5.1 What Prestige Is

Prestige is:
- A **scalar reputation value**
- Stored at:
  - rikishi level
  - beya level
- Persistent across basho
- Decays slowly without reinforcement

Prestige drives:
- banner attraction
- recruitment quality
- sponsor interest (abstracted)
- narrative prominence
- AI valuation of success

---

### 5.2 Prestige Gain Sources

| Event | Rikishi | Beya |
|---|---:|---:|
| Bout win | +small | +very small |
| Upset win | +medium | +small |
| Sanshō | +large | +medium |
| Yusho | +very large | +large |
| Yokozuna promotion | +huge | +huge |

---

### 5.3 Prestige Decay

Cadence: **per basho**

- Rikishi prestige decay: ~2–4%
- Beya prestige decay: ~1–2%

Decay never drops prestige below a minimum floor.

---

### 5.4 Prestige → Banner Multiplier

Banner attraction multiplier:
```
bannerScalar = 1 + log10(1 + prestige / K)
```

(K is a tuning constant.)

This gives:
- diminishing returns
- no runaway inflation

---

## 6. Beya Operating Economy

### 6.1 Regular Expenses (Recap)

**Cadence:** Weekly

- Wrestlers: ¥2,000 × roster size
- Staff: ¥6,000 × staff count
- Facilities: ¥1,000 × facility levels

These costs are **unavoidable**.

---

### 6.2 Capital Expenses

- Facility upgrades (one-time)
- Recruitment signing fees
- Emergency medical events (rare)

Capital spending does not affect prestige directly.

---

## 7. Retirement Funds (Rikishi-Level)

### 7.1 Purpose

Retirement funds:
- Provide long-term security
- Affect post-career options (coach, manager, governance)
- Do **not** affect active competition

---

### 7.2 Contributions

**Cadence:** Per banner win

From rikishi banner share:
- 70% liquid cash
- 30% automatically deposited into retirement fund

This is mandatory and deterministic.

---

### 7.3 Retirement Fund Usage

At retirement:
- Fund converts to:
  - cash payout
  - or investment into:
    - kabu (future governance)
    - coaching eligibility
    - stable succession (future)

Funds cannot be withdrawn early.

---

## 8. Insolvency System (Critical)

### 8.1 Solvency State Machine

Each beya exists in one of four states:

1. **Healthy**
2. **Stressed** (cash < 8 weeks of burn)
3. **Critical** (cash < 4 weeks)
4. **Insolvent** (cash < 0)

---

### 8.2 Deterministic Interventions

| State | Automatic Effects |
|---|---|
| Stressed | Recruitment frozen |
| Critical | Facility upgrades locked, warnings issued |
| Insolvent | Forced actions triggered |

---

### 8.3 Insolvent Resolution (Order)

1. Freeze spending
2. Downgrade facilities (sell levels)
3. Release staff
4. Forced retirements (lowest prestige)
5. Closure or merger (future governance)

No randomness. No surprise bankruptcy.

---

## 9. AI Interaction

AI managers:
- track weekly burn rate
- maintain cash buffers based on profile
- value prestige differently
- react strongly to insolvency thresholds

Gambler AI tolerates lower buffers.  
Survivor AI exits risk early.

---

## 10. Player UX Rules

Players see:
- weekly burn
- cash runway (weeks)
- prestige trends
- banner income summaries

Players never see:
- raw multipliers
- hidden decay math

---

## 11. Determinism & Auditability

All economic events emit logs:
- source
- amount
- actor
- timestamp

Replays always reproduce identical balances.

---

## 12. Canon One-Liner

> **The economy rewards success, punishes overreach, and turns reputation into opportunity — but it never forgives ignorance of the burn rate.**

---

End of document.
