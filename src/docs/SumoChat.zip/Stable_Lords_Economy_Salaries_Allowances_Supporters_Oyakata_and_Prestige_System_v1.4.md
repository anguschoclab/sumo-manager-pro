# Stable Lords — Economy, Salaries, Allowances, Supporters, Oyakata & Prestige System v1.4 (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-ready  
Supersedes: Economy, Salaries, Allowances, Supporters & Prestige System v1.3  

Scope: Defines the **complete institutional economy** of Stable Lords, aligned with real-world sumo practice:
- League-paid rikishi salaries (monthly)
- League-paid lower-division allowances
- Kenshō banner economics
- Kōenkai / Supporters Associations
- **Oyakata JSA salaries and stipends**
- **Elder stock (kabu) as a license, not a dividend asset**
- Beya operating budgets
- Retirement funds
- Insolvency, subsidy, and collapse logic

This document is the **single authoritative source of truth** for all money flows and prestige interactions.

---

## 1. Design Goals

The economy must:
- Reflect **real Japanese sumo institutional finance**
- Separate *personal income* from *institutional survival*
- Make stable ownership financially risky but legible
- Avoid passive-income exploits
- Be deterministic, auditable, and replay-safe
- Integrate with:
  - Banzuke, Scheduling & Awards
  - Beya Management
  - Training
  - NPC Manager AI
  - Governance & Kabu (future)

> Rank pays the wrestler. The JSA pays the elder. Supporters and sacrifice keep the stable alive.

---

## 2. Currency & Cadence

- Currency: ¥ (yen-equivalent)
- No inflation by default
- Cadence:
  - **Weekly**: beya operating costs
  - **Monthly**: rikishi salaries, allowances, oyakata salaries, kōenkai contributions
  - **Per-bout**: kenshō settlement
  - **Basho-end**: awards, promotions, prestige decay

---

## 3. Economic Accounts

Minimum required accounts:
- `LeagueTreasury` (abstract)
- `BeyaOperatingFund`
- `RikishiCash`
- `RikishiRetirementFund`
- `OyakataPersonalFund`

No account may auto-merge into another without an explicit rule.

---

## 4. Rikishi Pay (League-Funded)

### 4.1 Sekitori Monthly Salaries

| Rank | Monthly Salary |
|---|---:|
| Yokozuna | ¥3,000,000 |
| Ōzeki | ¥2,500,000 |
| Sekiwake | ¥1,800,000 |
| Komusubi | ¥1,700,000 |
| Maegashira | ¥1,400,000 |
| Jūryō | ¥1,100,000 |

Paid monthly by the league.  
Never enters beya operating funds.

---

### 4.2 Lower-Division Allowances

| Division | Monthly Allowance |
|---|---:|
| Makushita | ¥150,000 |
| Sandanme | ¥90,000 |
| Jonidan | ¥55,000 |
| Jonokuchi | ¥35,000 |

Allowances provide subsistence, not wealth.

---

## 5. Kenshō Banners (Performance Income)

- ¥70,000 per banner
- 50% → rikishi (personal)
- 50% → beya operating fund
- Settled immediately per bout
- Primary scalable revenue for beya

---

## 6. Kōenkai / Supporters Associations

(Recap, unchanged from v1.3)

| Strength | Monthly Contribution |
|---|---:|
| None | ¥0 |
| Weak | ¥50,000 |
| Moderate | ¥150,000 |
| Strong | ¥400,000 |
| Powerful | ¥800,000 |

Growth/decay tied to prestige, success, scandal, and leadership stability.

---

## 7. Oyakata Economics (NEW – Fully Specified)

### 7.1 Oyakata JSA Salary

All oyakata receive a **league-paid monthly salary**, independent of beya finances.

Indicative bands:

| Elder Status | Monthly Salary |
|---|---:|
| Standard Oyakata | ¥1,000,000 |
| Senior Committee Member | ¥1,300,000 |
| Executive / Director (Riji) | ¥1,600,000+ |

Exact role mapping is abstracted but deterministic.

Salary is paid into:
- `OyakataPersonalFund`

---

### 7.2 What Oyakata Salary Is (and Is Not)

- ✔ A **living wage**
- ✔ Enables continued participation in sumo
- ❌ Not intended to fund a beya by itself
- ❌ Not a prestige multiplier

By default, **no automatic transfer** occurs from oyakata salary to beya funds.

---

### 7.3 Oyakata Personal Subsidies (Recap + Clarified)

Oyakata may **voluntarily subsidize** their beya when it is distressed.

Rules:
- Triggered when beya enters *Stressed* or *Critical*
- Monthly cap (e.g., ¥100k–¥500k)
- Deterministic willingness based on manager profile
- Draws from `OyakataPersonalFund`

Subsidies:
- Do **not** generate prestige
- Are finite
- Increase long-term collapse risk if overused

---

## 8. Elder Stock (Kabu) — Canon Definition

### 8.1 What Kabu Is

Kabu is:
- a **license to remain in the JSA**
- a prerequisite for:
  - oyakata salary
  - coaching
  - governance roles
  - stable ownership

---

### 8.2 What Kabu Is Not

Kabu:
- ❌ Does **not** pay dividends
- ❌ Does **not** generate passive income
- ❌ Does **not** guarantee profit

Any “return” from kabu is indirect:
- access to salary
- eligibility for stipends and roles
- prestige-driven external opportunities
- resale value (volatile, private, future system)

---

### 8.3 Kabu & Financial Pressure

Because kabu itself produces no cash:
- elders often rely on savings + supporters
- kabu acquisition can create debt
- succession crises are financially dangerous

This is intentional and canonical.

---

## 9. Beya Operating Economy (Recap)

### 9.1 Weekly Operating Costs

| Expense | Formula |
|---|---|
| Wrestlers | ¥2,000 × roster |
| Staff | ¥6,000 × staff |
| Facilities | ¥1,000 × facility levels |

---

## 10. Retirement Funds (Recap)

- 30% of kenshō winnings
- 10% of salary/allowance
- Locked until retirement
- Used for post-career roles, kabu, succession

---

## 11. Solvency & Insolvency (Recap)

States:
- Healthy
- Stressed
- Critical
- Insolvent

Resolution order:
1. Freeze spending
2. Sell facilities
3. Release staff
4. Forced retirements
5. Kōenkai downgrade/loss
6. Oyakata subsidies
7. Closure / merger (governance)

No randomness.

---

## 12. AI Behavior With Oyakata Economics

AI managers:
- treat oyakata funds as **last resort**
- differ in subsidy tolerance:
  - Survivor: early, cautious
  - Traditionalist: reluctant
  - Gambler: late, risky
- plan succession more conservatively if subsidies are heavy

---

## 13. Player UX Rules

Players see:
- oyakata salary band (not exact role mechanics)
- subsidy events and amounts
- kōenkai contributions
- stable runway and warnings

Players never see:
- kabu internal valuations
- AI willingness thresholds

---

## 14. Canon One-Liners

- **On kabu:**  
  > “Elder stock is not an investment — it is the price of staying in the room.”

- **On stable finance:**  
  > “The league pays the wrestler and the elder; only supporters and sacrifice pay for the stable.”

---

End of document.
