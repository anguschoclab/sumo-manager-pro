# Stable Lords — Sumo Play-by-Play (PBP) System v1.3  
## Narrative Bout Rendering with Crowd Memory & Long-Term Venue Identity (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-grade  
Supersedes: PBP System v1.2

Scope: This document defines how **live sumo Play-by-Play (PBP)** is rendered in Stable Lords, extending the system with a **persistent crowd memory layer** that allows venues and audiences to remember:
- past heroes and villains
- famous bouts and scandals
- repeated disappointments or triumphs
- long-term emotional bias toward rikishi, stables, and oyakata

This system remains:
- narrative-first
- engine-faithful (Combat Engine V3)
- deterministic
- non-numeric in presentation

---

## 1. Why Crowd Memory Exists

Sumo crowds are not neutral.
They remember:
- who thrilled them
- who embarrassed them
- who always delivers
- who always disappoints

Crowd memory ensures that:
- reactions feel earned over time
- venues develop personality
- careers gain local flavor
- repeated appearances matter

> “A rikishi never enters an empty ring. He enters a room that remembers him.”

---

## 2. Crowd Memory Model (Backend)

### 2.1 Memory Scope

Crowd memory is tracked at **venue level** (not global):

- Ryōgoku (Tokyo)
- Osaka
- Nagoya
- Fukuoka

Each venue maintains independent memory profiles.

---

### 2.2 Memory Targets

Crowds remember:
- Rikishi
- Stables
- Oyakata (secondary)

Memory is never erased, only diluted.

---

### 2.3 Memory Dimensions (Hidden)

For each (Venue × Target), the engine tracks:
- Favorability
- Trust
- Expectation
- Fatigue (overexposure)

These are **never shown numerically**.

---

## 3. How Crowd Memory Is Built

Crowd memory updates when:

- a rikishi wins decisively
- an upset occurs
- a rivalry bout is resolved
- a mono-ii overturns expectations
- a scandal breaks
- a beloved rikishi retires

Repeated appearances reinforce memory faster than isolated events.

---

## 4. How Crowd Memory Decays

Memory decays:
- slowly over time
- faster if the rikishi/stable is absent
- unevenly (fame lasts longer than disappointment)

Fukuoka crowds decay slower than Tokyo crowds.

---

## 5. Crowd Memory → PBP Effects

Crowd memory modifies **reaction phrasing**, not outcomes.

### 5.1 Positive Memory Effects
- earlier murmurs
- quicker eruptions
- warmer language

Example:
> “The crowd is already stirring—this is a familiar favorite.”

---

### 5.2 Negative Memory Effects
- skepticism
- delayed reactions
- sharper silence

Example:
> “The hall watches cautiously—this crowd has seen this before.”

---

### 5.3 High Expectation Pressure
When expectation is high:
- minor mistakes draw gasps
- hesitation is emphasized

Example:
> “A brief pause—and the crowd reacts immediately.”

---

## 6. Crowd Memory + Regional Tone Interaction

Crowd memory is filtered through **regional broadcast tone**:

- **Tokyo:** restrained acknowledgment of history  
  > “A familiar name draws a response.”

- **Osaka/Nagoya:** emotionally responsive  
  > “The crowd remembers—and they lean in.”

- **Fukuoka:** openly expressive  
  > “The hall greets him like an old friend.”

---

## 7. Crowd Memory + Special Rulings

### Mono-ii
- Beloved rikishi → heightened tension
- Disfavored rikishi → sharper scrutiny

### Torinaoshi
- Crowd expectation increases
- Second clash reactions are faster, louder

### Mizui-iri
- Memory influences patience:
  - respected veterans → quiet respect
  - controversial figures → restless murmurs

---

## 8. Sample Bout with Crowd Memory

**Honbasho:** Haru Basho  
**Day:** 11  
**Division:** Makuuchi  
**Venue:** Ryōgoku (Tokyo)  
**Voice Style:** Formal

**East Maegashira 4 — Kiryuzan**  
**West Maegashira 3 — Takamori**

*(Kiryuzan has a history of dramatic wins in Tokyo)*

---

> “Day Eleven here at the Kokugikan.”  
> “Kiryuzan steps onto the dohyo—and there is a response from the crowd.”  
> “The gyoji calls them forward.”  
> “They meet squarely at the tachiai.”  
> “Takamori presses, but Kiryuzan holds firm.”  
> “A murmur—he’s found the belt.”  
> “The pressure builds.”  
> “A brief hesitation—heard immediately in the hall.”  
> “Now he drives forward.”  
> “Out.”  
> “The crowd responds warmly as Kiryuzan takes the bout.”

**Kimarite:** **Yorikiri**

---

## 9. Integration with Other Systems

- **Rivalries:** crowd memory amplifies rivalry reactions
- **Scandals:** memory shifts sharply negative and persists
- **Career Journals:** famous crowd moments become entries
- **Media:** headlines borrow crowd language (“the hall erupts”, “met with silence”)

---

## 10. Determinism & Safety

Given:
- same world seed
- same venue
- same historical events

Crowd memory produces identical PBP output.

No RNG applause.
No mood dice.

---

## 11. Canon One-Liners (Expanded)

- “Some halls never forget.”
- “Applause is earned long before the bout begins.”
- “A silence can carry years of memory.”

---

End of Sumo Play-by-Play System v1.3
