# Stable Lords — Sumo Play-by-Play (PBP) System v1.2  
## Narrative Bout Rendering with Crowd Dynamics & Regional Broadcast Tone (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-grade  
Supersedes: PBP System v1.1

Scope: This document defines how **live sumo Play-by-Play (PBP)** is rendered in Stable Lords, extending the system with:
- continuous narrative flow (no visible phases)
- backend fidelity to Combat Engine V3
- special ruling branches (mono-ii, torinaoshi, mizui-iri)
- commentator voice style matrix
- **crowd reaction modeling**
- **regional broadcast tone variants**
- deterministic narrative generation

---

## 1. Core Philosophy (Reaffirmed)

A sumo bout lasts seconds.  
The *experience* lasts minutes.

PBP exists to:
- communicate momentum, balance, and intent through language
- situate each bout within tradition and tournament context
- allow the crowd and broadcast tone to shape emotional weight
- remain fully deterministic and simulation-faithful

> “The ring decides the winner. The crowd decides how it is remembered.”

---

## 2. Narrative Flow Rules (Player-Facing)

- The bout reads as **one continuous narrative**
- No mechanical phase labels are shown
- Short, vivid lines are preferred over long exposition
- Silence and restraint are valid narrative beats

---

## 3. Commentator Voice Style Matrix (v1.1, Reaffirmed)

Voice is selected deterministically by:
- era preset
- broadcaster identity
- bout importance (rank, day, stakes)

### 3.1 Voice Styles

**Formal (Traditional NHK-style)**  
Restrained, ritual-focused, precise.

**Dramatic (High-stakes / Late Basho)**  
Heightened emotion, crowd-aware, decisive moments emphasized.

**Understated (Early Basho / Analytical)**  
Quiet, observational, implication over exclamation.

Voice affects cadence and adjective density, never facts.

---

## 4. Regional Broadcast Tone (NEW)

Regional tone overlays commentator voice and affects:
- word choice
- crowd emphasis
- pacing

### 4.1 Regional Tone Profiles

#### Tokyo (Ryōgoku / National)
- Balanced and authoritative
- Emphasizes rank, record, and historical context
- Crowd reactions are respectful, measured

Example:
> “A crucial exchange here for the Sekiwake.”

---

#### Osaka / Nagoya (Regional Major Basho)
- Warmer, more reactive
- Crowd emotion surfaces more clearly
- Momentum shifts are highlighted

Example:
> “You can feel the hall lean as the balance turns.”

---

#### Fukuoka (Kyushu Basho)
- Lively, intimate
- Crowd personality frequently referenced
- Upsets receive extra color

Example:
> “The crowd loves this—every push brings a roar.”

---

Regional tone never alters mechanics or outcomes.

---

## 5. Crowd Reaction System (NEW)

### 5.1 Crowd State Variables (Hidden)

The engine tracks:
- anticipation
- surprise
- tension
- release

These are derived from:
- bout importance
- rivalry history
- rank disparity
- rarity of outcome

---

### 5.2 Crowd Reaction Beats (Narrative)

Crowd reactions surface as:
- murmurs
- rising noise
- sharp gasps
- applause
- stunned silence

Examples:
- *“A murmur rolls through the hall.”*
- *“The crowd rises as one.”*
- *“A sharp intake of breath.”*

Crowd reactions are **descriptive, never quantified**.

---

### 5.3 Silence as Reaction

Silence is meaningful and used when:
- mono-ii is called
- a favored rikishi loses unexpectedly
- a decisive error occurs

Example:
> “The hall falls quiet as the judges step forward.”

---

## 6. Special Ruling Narrative Branches (Expanded)

### 6.1 Mono-ii
Crowd response:
- immediate hush
- delayed murmurs after decision

### 6.2 Torinaoshi
Crowd response:
- renewed tension
- sharper reactions on second clash

### 6.3 Mizui-iri
Crowd response:
- respectful quiet
- subdued applause as rikishi return

---

## 7. Sample Bout with Crowd & Regional Tone

**Honbasho:** Kyushu Basho  
**Day:** 13  
**Division:** Makuuchi  
**Venue Tone:** Fukuoka  
**Voice Style:** Dramatic

**East Maegashira 3 — Kiryuzan**  
**West Komusubi — Hoshitora**

---

> “Day Thirteen here in Fukuoka, and the crowd is fully invested now.”  
> “The gyoji calls them forward—no delay.”  
> “They crouch low at the shikiri-sen.”  
> “The fan drops—*tachiai!*”  
> “A violent clash! The sound echoes!”  
> “Hoshitora drives forward—the crowd responds!”  
> “Kiryuzan gives ground but keeps his balance!”  
> “A murmur spreads—he’s found the belt!”  
> “They drift toward the edge—voices rising!”  
> “Hoshitora hesitates—just for a moment!”  
> “Kiryuzan surges!”  
> “At the straw—out!”  
> “The hall erupts!”  

**Winner:** **Kiryuzan**  
**Kimarite:** **Yorikiri**

> “What a moment here in Kyushu! Kiryuzan turns the bout with patience and power!”

---

## 8. Backend Fidelity (Unchanged)

Internally, the engine still resolves:
- initiative
- grip
- momentum
- fatigue
- special rulings
- kimarite legality

Narrative selection occurs *after* outcome resolution.

---

## 9. Determinism Guarantee

Given:
- same world seed
- same bout state
- same venue

The same:
- crowd reactions
- regional tone
- PBP text

is generated.

---

## 10. Canon One-Liners (Expanded)

- “The crowd does not decide the bout—but it remembers it.”
- “Silence can be louder than cheers.”
- “Every hall has its own voice.”

---

End of Sumo Play-by-Play System v1.2
