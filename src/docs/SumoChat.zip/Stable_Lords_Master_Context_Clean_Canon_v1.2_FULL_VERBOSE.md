# Stable Lords / SumoGame — Master Context (Clean Canon v1.2 — Full)

Date: 2026-01-06  
Purpose: A **sprint-free**, restart-ready, fully explicit design bible describing the entire game, its systems, and the canonical tech/design contracts.

> This document is intended to be copy/pasted into a fresh chat as the full game context, and also used as the canonical reference for implementation.

---

## Table of Contents
1. Core Vision & Pillars  
2. Canonical Tech Stack (Stable Lords Tech Spec v1.0)  
3. Determinism Rules (Deterministic but Divergent)  
4. World Structure (including flexible beya count)  
5. Time, Calendar, and the Six-Basho Loop  
6. Beya (Stable) System: Founding, Succession, Closure  
7. Rikishi Identity, Growth, Style Evolution, and Career Phases  
   7.10 Dynamic State Attributes (Fatigue, Momentum, Injuries)  
8. Combat Engine V3 (Deterministic): Phase Model, Logs, Counters  
9. Banzuke (Ranking) System: Hierarchy and Promotion Heuristics  
10. The 82-Kimarite System (Option A): Registry + Weighting Matrix  
11. Economy: Kenshō, Prestige, Stable Funds, Retirement Funds  
   11.3 Rivalries  
   11.4 Scouting & Fog of War  
   11.5 Seasonal Tone & World Flavor  
12. Narrative Consumption Layer (Formalized)  
13. Data Contracts (Types) and Helper Modules  
   13.4 Kimarite Aliases and Post-Processing Labels  
14. Forward-Declared Systems (Canonical but Dormant)
---

# 1. Core Vision & Pillars (Canonical)

## Pillar 1 — Authenticity
Stable Lords is a **sumo management simulation** grounded in authentic structures:
- **Six basho per year**: Hatsu, Haru, Natsu, Nagoya, Aki, Kyushu.
- **Authentic rank hierarchy**: Yokozuna → Jonokuchi, with correct bout counts per division.
- **Kenshō banners**, payouts, and retirement funds as a core economic loop.
- **Beya-centered world** (stable culture, succession, reputation, facilities).

## Pillar 2 — Deterministic Simulation
- Every outcome is repeatable given the same **World Seed** and the same sequence of player choices.
- Combat is deterministic under seeded RNG (seedrandom), with **data-driven endings** from the 82-kimarite registry.

## Pillar 3 — Narrative-First
- Every bout generates a structured log of phases and pivotal moments.
- Systems (rivalries, seasonal tone, scandals, succession) are explicitly designed to produce “headlines” and story hooks.
- The sim should feel like it creates drama *without* scripting outcomes.

## Pillar 4 — Always Playable
- The build must boot locally and remain navigable at all times.
- Missing features must be guarded and degrade gracefully:
  - seeded demo data
  - stubbed services
  - safe UI states, empty-state copy, and error boundaries
  - offline-friendly packaging patterns

---

# 2. Canonical Tech Stack (Stable Lords Tech Spec v1.0)

**Frontend Core**
- React (Vite) + TypeScript
- Zustand + Immer (state)
- Tailwind + Radix UI (layout/controls/dialogs)
- React Router (navigation)
- React Hook Form (configuration flows)

**Simulation Systems**
- Custom TypeScript sim engine
- seedrandom for deterministic outcomes
- Comlink + Web Workers for parallel simulation (long ticks, world updates)
- Zod for data validation
- Optional Ink.js for narrative integration (storylets generated from logs/events)

**Persistence & Packaging**
- Dexie.js for IndexedDB saves
- pako + JSZip for compression/export
- versioned Dexie migrations
- Vite PWA for offline play

**Audio/Visual Layer**
- howler.js (sound)
- Framer Motion (animation)
- Lucide React (icons)
- Recharts (analytics)
- react-markdown (dynamic text rendering)

**Tooling**
- Vite / ESBuild
- ESLint + Prettier
- Vitest + React Testing Library
- GitHub Actions (build automation)

---

# 3. Determinism Rules (Deterministic but Divergent)

## 3.1 World Seed
A single **World Seed** deterministically drives:
- world generation (beya count, starting rosters, initial attributes)
- schedule generation rules (where applicable)
- combat RNG (via bout seeds derived from world seed + participants + match identifiers)

## 3.2 Divergence That’s Allowed (Still Deterministic)
The world is deterministic, but outcomes can still vary because inputs vary:
- training choices
- facility upgrades
- scouting decisions (when introduced)
- roster changes (recruitment, transfers, retirements)
- event triggers (seasonal events, scandals, injuries) *when those triggers are themselves deterministic*

## 3.3 Forbidden Non-Determinism
When operating in canonical deterministic mode:
- do **not** call `Date.now()` inside simulation logic
- do **not** use unseeded `Math.random()`
- do **not** run asynchronous UI timing that affects sim results

---

# 4. World Structure

## 4.1 Flexible Beya Count
- Initial world spawns approximately **42 stables**, randomized within **39–45**.
- Long-term world target remains “around 42” but flexible to support:
  - new stable founding by retired rikishi
  - stable closure on failed succession
- Soft world bounds: typically **35–50 active stables**.

## 4.2 Core Entities (High Level)
- **Heya (Stable)**: roster, oyakata, funds, reputation, facilities.
- **Rikishi**: permanent identity + evolving body + evolving performance profile.
- **BashoState**: schedule, results, day progression, standings.
- **WorldState**: seed, time, entity registries, history.

---

# 5. Time, Calendar, and the Six-Basho Loop

## 5.1 Annual Loop
- 6 basho per in-game year.
- Basho index cycles (0–5) across: Hatsu, Haru, Natsu, Nagoya, Aki, Kyushu.

## 5.2 Time Progression Modes
- **During basho**: advance by **day** (Day 1–15).
- **Between basho**: advance by **week** (interim).

## 5.3 Interim Length
- Interim phase is **6 weeks** bridging tournaments.

---

# 6. Beya (Stable) System: Founding, Succession, Closure

## 6.1 Oyakata Eligibility (Rules + Hook)
A candidate must satisfy:
- Rank/standing threshold (design intent: sanyaku-caliber career)
- Age ≥ 28
- Clean conduct (no severe sanctions)
- Access to elder stock line (kabu/toshiyori) when governance is fully modeled

## 6.2 Succession Rules (Explicit)
**Trigger moments**
- end of each basho (review hook)
- oyakata retirement
- oyakata death/disqualification (event-driven)

**Selection pipeline**
1. Identify successor pool
   - internal candidates (stable elders, retired stars)
   - external candidates (available elder stock holders)
2. Score candidates
   - leadership, reputation, prestige
   - loyalty and stable cohesion
   - finances/facilities compatibility
   - conduct and reliability
3. Select successor if any clears threshold
4. If no successor clears threshold → closure or merge (merge is optional/future)

## 6.3 Closure Rules (Full)
A stable closes when any of the following occurs:
- oyakata retires/dies and no qualified successor exists
- forced dissolution due to severe governance sanction (future: match-fixing, violence)
- insolvency after grace period and rescue attempts (future: loans/benefactors)

## 6.4 Founding New Stables (Detailed)
A new stable may be founded when:
- a qualified retired rikishi obtains elder stock
- world cap is not exceeded (soft constraint)
- minimum funds/facilities are met (can be modest)

Founding creates:
- new heya entity with seeded facilities
- reputation baseline
- recruitment slots and a “founding narrative” headline

---

# 7. Rikishi Identity, Growth, Style Evolution, and Career Phases

## 7.1 Permanent Identity
Permanent data (never changes):
- unique `id`
- unique `shikona` (generated from weighted syllables; uniqueness enforced)
- `nationality` and other origin metadata (if used)

## 7.2 Evolving Physique (Current + Potential)
Rikishi **height, weight, and style evolve over time**.
- Each rikishi has **current** and **potential** height/weight.
- Not all rikishi reach potential (fulfillment is deterministic and variable).

See **Career Phase Model** below for how growth plays out.

# 7.7 Career Phase Model (Growth → Prime → Decline)

Stable Lords models a rikishi as a **long-lived, evolving athlete**. The goal is that careers generate believable arcs and narrative beats, while remaining deterministic under a seed.

## A) Career Phases (Conceptual)
> Phase boundaries are not hard-coded ages; they are computed from age + physique fulfillment + injury history + performance trajectory.

### 1) Youth / Prospect
- **Theme:** potential not yet realized.
- **Physique:** height and weight trend toward potential at the highest rate.
- **Skills:** “spiky” improvements; technique and balance can jump with good coaching.
- **Style drift:** most likely here (oshi ↔ hybrid ↔ yotsu can meaningfully shift).

### 2) Development / Rise
- **Theme:** specialization begins.
- **Physique:** weight approaches a chosen “fighting mass”; height growth slows/ends.
- **Skills:** steadier gains; archetype expression becomes clearer.
- **Favorites:** tokui-waza begins to stabilize (top 2–3 emerge).

### 3) Prime
- **Theme:** highest consistency and conversion rate.
- **Physique:** stable; weight may oscillate seasonally with training blocks.
- **Skills:** gains are marginal; consistency and composure dominate.
- **Favorites:** signature move set is established; counters improve with experience.

### 4) Veteran / Decline
- **Theme:** adaptation under constraint.
- **Physique:** weight may increase (or decrease due to injury management); speed often declines first.
- **Skills:** technique/experience remain strong, but physical outputs fall.
- **Style drift:** often toward **yotsu/hybrid** for control or toward **trickster** patterns for survival (depending on attributes).

### 5) Late Career / Exit
- **Theme:** legacy, succession, and story closure.
- **Physique:** managed; injuries accumulate; fatigue sensitivity high.
- **Outcomes:** retirement triggers governance hooks (succession / stable founding).

## B) Current vs Potential Physique (Data Contract)
Each rikishi stores:
- `heightCurrentCm`, `heightPotentialCm`
- `weightCurrentKg`, `weightPotentialKg`
- `growthFulfillment` (0–1): how much of potential is realistically reachable
- `growthRateProfile` (seeded): “early bloomer”, “late bloomer”, “steady”, etc.

**Deterministic rule:** growth changes are deterministic from (seed + age + training + injury). No pure randomness.

## C) Physique → Style + Kimarite Feedback Loop
As physique changes, it should influence:
1. **Style** (oshi/yotsu/hybrid) recalculation
2. **Grip success** probability in clinch phase
3. **Kimarite selection weights**
4. **Favorite moves drift** (tokui-waza)

Example effects:
- +weight +power → increases force-out conversion, pushes `oshidashi/yorikiri` frequency upward
- +balance +technique → increases throws/twists in belt stances
- +speed +agility → increases trips/evasion, raises lateral position events
- accumulated injuries → decrease speed burst, raise “short finish” behaviors (slap/pull, quick pushdowns)

## D) “Not Everyone Reaches Potential” (Fulfillment Rules)
A rikishi may fail to reach potential due to:
- repeated injury interrupts growth/training
- poor facility quality (nutrition/recovery)
- mismatch between training intensity and body type
- chronic fatigue from overtraining
- (optional later) personality traits: discipline, professionalism, risk appetite

This creates believable variance in career arcs without breaking determinism.


## 7.8 Style Evolution (Explicit)
Style is a **current classification**, and can drift across a career:
- `oshi`: distance, pushing/thrusting, linear pressure
- `yotsu`: belt control, throws/twists/lifts, clinch dominance
- `hybrid`: adaptable toolbox, can win from both distance and grip states

**Style update cadence (Option A):**
- recompute at end of each basho (or quarterly in interim)
- apply hysteresis thresholds to prevent sudden flips

**Inputs to recompute style**
- physique deltas (weight/height changes)
- observed kimarite distribution (which finishes actually occur)
- grip success distribution (belt-dominant frequency)
- coaching emphasis (if modeled)
- archetype as a soft bias, not a hard lock

## 7.9 Tokui-waza / Favorite Moves Drift
- `favoredKimarite` reflects the top 2–3 winning finishes.
- It is updated after each win and displayed on the rikishi card.
- As physique/style changes, the favored list should *naturally* drift.


## 7.10 Dynamic State Attributes (Fatigue, Momentum, Injuries)

In addition to “long arc” attributes (physique, skills, style), each rikishi carries **short-term dynamic state** that changes frequently and meaningfully shapes outcomes. These values exist to produce believable arcs (“he was gassed,” “he peaked late,” “his knee betrayed him”) while staying deterministic.

### 7.10.1 Fatigue (0–100)

**Definition:** A scalar representing accumulated physical strain and reduced readiness.

**How fatigue increases**
- **During basho:** each bout adds fatigue based on:
  - bout length (number of momentum ticks)
  - explosive actions (tachiai burst, repeated lateral recoveries)
  - mass vs opponent (heavy collisions cost more)
  - current injury status (injured athletes fatigue faster)
- **Between basho (training):** fatigue increases with training intensity and decreases with recovery emphasis.

**How fatigue recovers**
- **Interim weeks:** baseline recovery each week.
- **Facilities:** better recovery/nutrition facilities increase recovery per week.
- **Training choices:** recovery blocks, deload weeks, or conservative programs accelerate recovery.

**Mechanical effects (canonical)**
- High fatigue reduces:
  - tachiai burst (initiative probability)
  - speed/agility contribution during momentum ticks
  - counter success (especially late-bout recoveries)
- High fatigue increases:
  - injury risk
  - “short finish” likelihood (slap/pull, quick pushdowns) as the engine prefers quicker resolutions when output is low.

**Narrative effects**
- Log phrasing should reflect fatigue at meaningful thresholds (e.g., “legs looked heavy,” “couldn’t reset his base”).

### 7.10.2 Momentum / Form (–10 to +10)

**Definition:** A short-term representation of confidence, rhythm, and execution sharpness.

**How momentum changes**
- Increases from:
  - winning streaks
  - upsets (especially against higher rank)
  - rivalry wins (see §11.3)
  - clutch finishes (late bout recoveries)
- Decreases from:
  - losing streaks
  - repeated one-sided losses
  - injury setbacks
  - scandal / discipline events (when modeled)

**Decay**
- Momentum naturally decays during interim so the world doesn’t become permanently “hot” or “cold.”
- The decay rate is deterministic and may be influenced by discipline traits (future), facilities, and stable culture (future).

**Mechanical effects (canonical)**
- Momentum slightly biases:
  - tachiai advantage
  - conversion rate once a finisher is selected (not the selection itself, which remains registry-driven)
- Momentum can raise volatility in rivalry bouts (see §11.3).

**Narrative effects**
- Momentum drives commentary tone: “in form,” “slumping,” “found his rhythm.”

### 7.10.3 Injury State (Deterministic)

**Definition:** Injuries are stateful conditions that apply attribute penalties and recovery timelines.

**Injury model**
- Each injury tracks:
  - `severity` (light / moderate / severe)
  - `affectedOutputs` (e.g., speed, balance, power, stamina)
  - `recoveryWeeksRemaining`
  - `recurrenceRisk` modifier (higher after prior injuries of the same type)

**How injuries occur**
- Injuries are deterministic outcomes derived from:
  - current fatigue
  - mass and collision intensity
  - training intensity
  - prior injury history
  - bout patterns (long, grinding matches raise risk)
  - seed and state, never unseeded randomness

**Mechanical effects (canonical)**
- Attribute penalties apply immediately.
- Recovery reduces penalties gradually or stepwise per week (implementation choice, but deterministic).
- Injuries increase likelihood of style drift toward control or survival patterns late career (§7.7).

**UI expectations**
- Injury status must be visible, with a clear recovery timeline.
- When attributes are hidden by scouting (§11.4), injuries remain visible as “observable truth.”

---

# 8. Combat Engine V3 (Deterministic): Phase Model, Logs, Counters

## 8.1 Phase Model (Canonical)
1. **Tachiai**  
   - determine initial advantage from (power, speed, balance, aggression, momentum)
   - apply archetype tachiai bonus and matchup bonuses
   - weight advantage (mass) modifies outcomes

2. **Clinch / Grip Battle**  
   - decide stance outcome:
     - `belt-dominant`
     - `push-dominant`
     - `no-grip`
     - `migi-yotsu`
     - `hidari-yotsu`
   - stance selection depends on grip preferences, style, technique/experience deltas

3. **Momentum Ticks**  
   - fatigue accumulates; advantage can shift
   - volatility increases lateral and rear position events
   - counters/recoveries depend on balance + experience + archetype counter bonus

4. **Finisher Window (82 Kimarite)**  
   - filter registry by stance/position/grip rules
   - weight remaining options using matrix + affinities + favorites
   - optionally trigger counter-attack resolution and flip winner

5. **Result & Log**  
   - produce `BoutResult`
   - produce structured narrative log entries for each phase

## 8.2 Narrative Log Contract
Each bout produces log entries shaped like:
- phase: `tachiai | clinch | momentum | finish`
- description: player-readable line
- data: structured numbers/flags for UI and analytics

---

# 9. Banzuke (Ranking) System

## 9.1 Hierarchy
- Makuuchi: Yokozuna, Ozeki, Sekiwake, Komusubi, Maegashira (M1–M17 E/W)
- Juryo (J1–J14 E/W)
- Makushita, Sandanme, Jonidan, Jonokuchi

## 9.2 Bouts per Basho
- Sekitori (Juryo+): 15 bouts
- Lower divisions: 7 bouts

## 9.3 Kachi-koshi / Make-koshi
- kachi-koshi = majority wins (8/15 or 4/7)
- make-koshi = majority losses

## 9.4 Promotion Heuristics (Explicit)
- Ozeki: ~33 wins across 3 basho in sanyaku
- Yokozuna: deliberation, typically consecutive yusho or equivalent
- Makushita → Juryo: usually requires high Makushita rank + strong record

---

# 10. The 82-Kimarite System (Option A)

## 10.1 Canonical Purpose
The 82-kimarite system is the **action space** for fight endings:
- it enforces authenticity and variety
- it enables narrative and scouting (players learn “what this rikishi does”)
- it creates emergent tokui-waza and career identity

## 10.2 The 82 Kimarite List (Option A — IDs and Names)
This is the Option A canonical list used by the sim registry.

- `yorikiri` — **Yorikiri**
- `oshidashi` — **Oshidashi**
- `oshitaoshi` — **Oshitaoshi**
- `yoritaoshi` — **Yoritaoshi**
- `hatakikomi` — **Hatakikomi**
- `hikiotoshi` — **Hikiotoshi**
- `tsukiotoshi` — **Tsukiotoshi**
- `tsukidashi` — **Tsukidashi**
- `katasukashi` — **Katasukashi**
- `kotenage` — **Kotenage**
- `uwatenage` — **Uwatenage**
- `shitatenage` — **Shitatenage**
- `sukuinage` — **Sukuinage**
- `kubinage` — **Kubinage**
- `kakenage` — **Kakenage**
- `shitatedashinage` — **Shitatedashinage**
- `uwatedashinage` — **Uwatedashinage**
- `sotogake` — **Sotogake**
- `uchigake` — **Uchigake**
- `ketaguri` — **Ketaguri**
- `okuridashi` — **Okuridashi**
- `okuritaoshi` — **Okuritaoshi**
- `okurihikiotoshi` — **Okurihikiotoshi**
- `okuritsukiotoshi` — **Okuritsukiotoshi**
- `okurinage` — **Okurinage**
- `tsuridashi` — **Tsuridashi**
- `tsuriotoshi` — **Tsuriotoshi**
- `abisetaoshi` — **Abisetaoshi**
- `sabaori` — **Sabaori**
- `kirikaeshi` — **Kirikaeshi**
- `komatasukui` — **Komatasukui**
- `harimanage` — **Harimanage**
- `haraiotoshi` — **Haraiotoshi**
- `kirinuke` — **Kirinuke**
- `ipponzeoi` — **Ipponzeoi**
- `kimedashi` — **Kimedashi**
- `kimekomi` — **Kimekomi**
- `shitatehineri` — **Shitatehineri**
- `uwatehineri` — **Uwatehineri**
- `susoharai` — **Susoharai**
- `sotokomata` — **Sotokomata**
- `uchimuso` — **Uchimuso**
- `sotomuso` — **Sotomuso**
- `ashitori` — **Ashitori**
- `haritsuke` — **Haritsuke**
- `nodowa` — **Nodowa**
- `tokkurinage` — **Tokkurinage**
- `yaguranage` — **Yaguranage**
- `mitokorozeme` — **Mitokorozeme**
- `tsutaezori` — **Tsutaezori**
- `izori` — **Izori**
- `okuritsuridashi` — **Okuritsuridashi**
- `tsukaminage` — **Tsukaminage**
- `nichonage` — **Nichonage**
- `zuban` — **Zuban**
- `fumikomi` — **Fumikomi**
- `guntingeri` — **Guntingeri**
- `kawazugake` — **Kawazugake**
- `kawazugakenage` — **Kawazugakenage**
- `kawazugakeotoshi` — **Kawazugakeotoshi**
- `okuritsukiotoshi` — **Okuritsukiotoshi**
- `okuritsuriotoshi` — **Okuritsuriotoshi**
- `hansoku` — **Hansoku**
- `hikiwake` — **Hikiwake**
- `fusensho` — **Fusensho**
- `fusenpai` — **Fusenpai**
- `tsukiotoshiotoshi` — **Tsukiotoshiotoshi**
- `harimanageotoshi` — **Harimanageotoshi**
- `shumokuzori` — **Shumokuzori**
- `kakezori` — **Kakezori**
- `susoharaiotoshi` — **Susoharaiotoshi**
- `sotogakeotoshi` — **Sotogakeotoshi**
- `uchigakeotoshi` — **Uchigakeotoshi**
- `uwatenageotoshi` — **Uwatenageotoshi**
- `shitatenageotoshi` — **Shitatenageotoshi**
- `komatasukuiotoshi` — **Komatasukuiotoshi**
- `sukuinageotoshi` — **Sukuinageotoshi**
- `yorikiriotoshi` — **Yorikiriotoshi**
- `oshidashiotoshi` — **Oshidashiotoshi**
- `yoritaoshiotoshi` — **Yoritaoshiotoshi**
- `okuridashiotoshi` — **Okuridashiotoshi**
- `okuritaoshiotoshi` — **Okuritaoshiotoshi**

## 10.3 Archetype → Kimarite Usage Matrix (How the Engine Weights the 82)

This is the **“Option A”** weighting concept. The actual engine computes weights per move from:
- `baseWeight`
- `styleAffinity`
- `archetypeBonus`
- `preferredClasses`
- stance & position multipliers
- favorite-move multiplier
- rarity dampening

To make those decisions transparent and tuneable, we define a **matrix of intent**.

### A) Preferred Kimarite Classes by Archetype (Multipliers)
These multipliers apply *after* baseWeight + affinities, before random selection.

| Archetype | force_out/push/thrust | throw/twist/lift | slap_pull | trip/evasion | rear | special |
|---|---:|---:|---:|---:|---:|---:|
| **Oshi Specialist** | **1.45×** | 0.85× | 1.10× | 0.95× | 1.05× | 0.80× |
| **Yotsu Specialist** | 1.05× | **1.55×** | 0.90× | 0.95× | 1.15× | 1.00× |
| **Speedster** | 1.05× | 0.90× | 1.20× | **1.60×** | 1.10× | 0.95× |
| **Trickster** | 0.85× | 0.95× | **1.65×** | **1.35×** | 1.05× | 1.20× |
| **All‑Rounder** | 1.15× | 1.15× | 1.10× | 1.10× | 1.10× | 1.00× |

**Notes**
- “rear” is mostly unlocked by **position** (rear), so multipliers here are modest.
- “special” is narrative spice: higher for Trickster, dampened for Oshi.
- This matrix is a *design control*; the registry’s per‑move bonuses should align with it.

### B) Stance → Class Bias (Multipliers)
These are global stance multipliers that stack with archetype multipliers.

| Stance | force_out/push/thrust | throw/twist/lift | slap_pull | trip/evasion | rear |
|---|---:|---:|---:|---:|---:|
| **push-dominant** | **1.45×** | 0.85× | 1.20× | 1.10× | 1.00× |
| **belt-dominant** | 0.95× | **1.55×** | 0.90× | 1.00× | 1.10× |
| **migi-yotsu / hidari-yotsu** | 1.00× | **1.45×** | 0.95× | 1.05× | 1.10× |
| **no-grip** | 1.05× | 0.65× | **1.30×** | **1.20×** | 0.80× |

### C) Position → Vector Bias (Multipliers)
| Position | frontal vector | lateral vector | rear vector |
|---|---:|---:|---:|
| **frontal** | **1.15×** | 1.00× | 0.70× |
| **lateral** | 1.00× | **1.20×** | 0.85× |
| **rear** | 0.80× | 0.95× | **2.25×** |

### D) Favorite Moves (Tokui-waza) Multiplier
If the selected move is in the attacker’s `favoredKimarite[]`:
- multiply weight by **2.0×** (Option A default)

This is the main mechanism that causes **signature moves to emerge organically** as careers progress.


---

# 11. Economy: Kenshō, Prestige, Stable Funds, Retirement Funds

## 11.1 Kenshō Payout (Option A)
Per banner:
- ¥10,000 → stable funds (immediate)
- ¥50,000 → rikishi retirement fund
- remaining portion treated as fees/overhead (narratively consistent with banner cost structure)

## 11.2 Prestige
Prestige is a scalar used to:
- influence kenshō attraction
- influence narrative spotlighting (and later rivalry heat)
Prestige decays during interim to prevent runaway snowballing.


## 11.3 Rivalries (Canonical)

Stable Lords models **persistent interpersonal rivalries** to increase story density and to create meaningful “headlines” from repeated meetings—without scripting winners.

### 11.3.1 Rivalry Object
A rivalry is a world entity linking two rikishi:
- `rikishiAId`, `rikishiBId`
- `heat` (0–100)
- `keyMoments[]` (bout IDs, basho IDs, tags like “upset”, “playoff”, “injury”)
- `lastUpdatedTick`

### 11.3.2 Heat Generation
Heat increases deterministically from:
- repeated matchups within a short window
- close bouts (multiple momentum reversals, narrow finishes)
- upsets (lower rank beats higher rank)
- title races (late basho contention, senshuraku stakes)
- playoffs / decisive bouts

Heat decays during interim to prevent permanent inflation.

### 11.3.3 Mechanical Effects
Rivalry heat modifies (subtle, not overpowering):
- tachiai intensity and initiative volatility
- risk appetite (more commitment on finish attempts, more counter windows)
- narrative emphasis (logs become “louder,” headlines more likely)

**Rule:** rivalry effects increase variance but do not override core attribute logic.

### 11.3.4 Narrative Effects
Rivalries feed:
- headline selection priority
- commentary tone (“bad blood,” “unfinished business”)
- scouting interest (see §11.4)

---

## 11.4 Scouting and Fog of War (Canonical)

Stable Lords supports a “fog of war” layer where some information about opponents is uncertain until observed.

### 11.4.1 What Can Be Hidden
By default, some attributes may be hidden or shown as ranges:
- technique nuance (throw timing, grip craft)
- injury resilience / durability tendencies
- composure / mental stability (future trait)
- growth fulfillment ceiling (how close they’ll reach potential)

### 11.4.2 How Information Is Revealed
Scouting reveals truth through deterministic observation:
- watching bouts (public information)
- repeated matchups (rivalry exposure)
- stable reports / coach notes (future)
- deliberate scouting actions (future menu)

### 11.4.3 Output Format
Scouting outputs are expressed as:
- confidence ranges
- “analyst notes” with evidence hooks (e.g., “wins spike in belt-dominant stances”)
- narrative rumors (when enabled), which should never contradict confirmed truth

**Hard rule:** scouting never lies; it only ranges uncertainty until revealed.

---

## 11.5 Seasonal Tone and World Flavor (Canonical)

Each basho has a **seasonal tone** that flavors narrative and applies light systemic bias:
- Winter, Spring, Summer, Autumn

### 11.5.1 Narrative Use
Seasonal tone influences:
- headline language
- crowd mood and “feel”
- travel fatigue framing
- injury story framing (“cold joints,” “summer grind”)

### 11.5.2 Light Mechanical Bias
Season can subtly influence:
- fatigue recovery rates
- injury likelihood modifiers
- travel stress (if modeled)

All seasonal effects must remain deterministic and modest; the primary role is tone.

---

# 12. Narrative Consumption Layer (Formalized)

Stable Lords is **narrative-first**, but the narrative system is explicitly treated as a **consumer** of simulation—not a driver of outcomes.

## 12.1 Principle: Narrative Never Changes Results
- No narrative system may alter:
  - bout winners
  - injuries
  - promotions
  - economy outcomes
- Narrative is derived from the same deterministic state, ensuring replayability and debuggability.

## 12.2 Inputs (Sources of Narrative Truth)
Narrative pulls from:
- bout phase logs (§8.2)
- rivalry objects (§11.3)
- seasonal tone (§11.5)
- prestige deltas (§11.2)
- succession/founding/closure events (§6)
- injuries and comebacks (§7.10)

## 12.3 Outputs (What Narrative Produces)
Narrative outputs include:
- **Headlines**: short “news hits” surfaced at day-end or basho-end
- **Storylets** (future): longer, Ink.js-ready moments derived from tags and thresholds
- **Analyst Commentary**: contextual reading of stats and trends (ties into scouting §11.4)
- **Retrospectives**: rivalry and career milestone recaps

## 12.4 Canonical Headline Selection (Deterministic)
Headline generation is deterministic:
- gather candidate events (upsets, streaks, injuries, rivalry spikes, succession events)
- score candidates by importance (rank stakes, rarity, heat, prestige)
- select top N headlines with diversity constraints (avoid repeats)
- render using season + rivalry tone modifiers

**Rule:** if two playthroughs produce the same event stream, they produce the same headlines.

# 13. Data Contracts (Types) and Helper Modules

## 13.1 Canonical Types
- `types.ts`: Style, Stance, TacticalArchetype, Rikishi, Heya, BashoState, WorldState, etc.
- Ensure data includes:
  - current + potential physique fields
  - career phase / growth fulfillment fields
  - favored kimarite tracking

## 12.2 Canonical Helper Modules
- `banzuke.ts`: rank hierarchy, formatting, kachi-koshi checks, kadoban logic
- `kimarite.ts`: registry + lookup helpers
- `boutEngineV3.ts`: deterministic multi-phase sim + logs

## 12.3 “One Source of Truth” Rules
- The kimarite registry defines the allowed endings and their metadata.
- The bout engine must not hardcode special-case endings except:
  - forfeits (if modeled as special results)
  - safety/guardrails (e.g., missing data fallback)

---

End of Clean Canon v1.1 (Full)

## 13.4 Kimarite Aliases and Post-Processing Labels (Canonical)

The **82-kimarite registry is fixed** as the win space. However, the UI and narrative layer may add **post-processing labels** to increase readability and flavor without bloating the registry.

### 13.4.1 Allowed Post-Processing
- descriptive suffixes (“late”, “edge”, “counter”, “on the straw”)
- alias display names (presentation-only)
- contextual “otoshi-style” labels if the finish is the same official kimarite but executed in a particular way

### 13.4.2 Constraints
- these labels must never be treated as new kimarite IDs
- the bout engine still records the official kimarite as the canonical result
- analytics should aggregate by official kimarite ID, with optional drill-down by label

### 13.4.3 Purpose
- keep authenticity (official 82 remain intact)
- keep tuning stable (avoid multiplying balance knobs)
- preserve narrative richness and commentary specificity

# 14. Forward-Declared Systems (Canonical but Dormant)

This section defines systems that are **canonically real** in the Stable Lords world but may be **mechanically inactive** in early builds. They are declared now so current systems can expose clean hooks, the data model remains future-proof, and later activation does not require retconning history.

## 14.0 Global Rules for Dormant Systems

### 14.0.1 Canon vs Activation
A system may be:
- **Canonically acknowledged**: it exists in-lore, can be referenced in headlines, and can have placeholder UI.
- **Mechanically dormant**: no player-facing controls and no hidden outcome changes.

Dormant systems may generate narrative flavor, but must not create surprise outcomes.

### 14.0.2 Determinism
When activated, each system must obey:
- outcomes derived from **World Seed + world state + explicit player choices**
- no unseeded randomness
- triggers must be reproducible given the same input stream

### 14.0.3 Hook-First Implementation
Even while dormant, each system should have:
- a minimal **data footprint**
- a single **simulation entry point** (“hook” in tick processing)
- a narrative integration point (headline tags)
- a guarded UI placeholder that explains “not active yet” (Always Playable)

### 14.0.4 No-Retcon Contract
Activation must not invalidate previously generated history. Where needed, interpret earlier worlds as having operated under “implicit/simple” versions of governance and finance.

---

## 14.1 Governance V1 (Kabu Availability, Council Politics)

Governance models the institutions that constrain stable ownership, succession, and legitimacy.

### 14.1.1 Core Concept
In early versions, oyakata eligibility exists as a clear rule hook (§6.1). Governance V1 formalizes the “institutional layer”:
- **kabu (elder stock)** constraints (finite resource)
- a governing body that arbitrates edge cases
- reputational / political dynamics affecting approvals and sanctions

Governance V1 is not grand strategy; it is a constraint + narrative generator with limited levers.

### 14.1.2 Kabu Pool
The world contains a finite pool of kabu units.
Each kabu can be:
- held by an eligible retired rikishi
- vacant/unassigned
- tied to a prestige tier for narrative color

**Effects**
- **Succession:** best candidate may still fail without kabu access.
- **Founding:** new stable creation requires kabu and governance approval.

### 14.1.3 Council Layer (Light Politics)
A council exists to:
- approve/deny succession outcomes
- investigate scandals
- issue sanctions (warnings → suspensions → forced dissolution in severe cases)

### 14.1.4 Decision Inputs
Governance decisions consider:
- candidate prestige and legacy
- stable reputation
- conduct flags (violence, match-fixing suspicion)
- financial solvency risk

### 14.1.5 Example: Succession with Governance
1. Oyakata retires.
2. Candidate pool built (internal + external).
3. Candidates scored (leadership, loyalty, finances, conduct).
4. Governance checks kabu access and legitimacy.
5. Outcome:
   - approved successor
   - interim caretaker (optional)
   - denial → closure or merger pathway

### 14.1.6 Data Footprint (Minimal)
Suggested entities:
- `KabuStock { id, prestigeTier, currentHolderRikishiId?, status }`
- `GovernanceCase { id, type, involvedIds, severity, resolution, createdAtTick }`
- `GovernanceProfile { heyaId, legitimacyScore, conductScore, politicalCapital }`

### 14.1.7 Dormant Mode Behavior
- kabu treated as implicitly available for qualified candidates
- council does not block actions; it may only generate narrative headlines

---

## 14.2 Stable Mergers (Optional Alternative to Closure)

Mergers are a safety valve and a narrative machine: when succession fails, a stable may be absorbed rather than disappear.

### 14.2.1 Trigger Conditions
Mergers are considered when:
- no successor clears threshold at retirement/death
- the stable still has value (facilities, roster, legacy)
- another stable is willing and able to absorb

### 14.2.2 Selecting Merger Partners
Candidate recipient stables are scored by:
- roster capacity
- reputation tier proximity (optional)
- culture compatibility (oshi/yotsu emphasis can matter narratively)
- finances and stability
- rivalry entanglements (mergers can intensify story)

### 14.2.3 Merger Outcomes
- **Full absorption:** closing stable ceases; roster transfers; facilities convert to value or upgrades.
- **Lineage preservation (optional):** stable name survives as a “branch identity” for narrative.
- **Split absorption (rare):** roster split across multiple stables (high complexity; use sparingly).

### 14.2.4 Effects on Rikishi
- morale/loyalty impacts (short-term momentum changes)
- training environment changes (facility access and coaching emphasis)
- rivalry reshaping (forced cohabitation and new frictions)

### 14.2.5 Dormant Mode Behavior
- default remains closure (§6.3)
- mergers may appear as narrative-only “rumors” with no mechanical effect

---

## 14.3 Loans and Benefactors (Insolvency Rescue)

This system expands the economy into long arcs: survival stories, obligations, and pressure.

### 14.3.1 Core Concept
A stable can enter distress due to:
- poor performance (low prestige → fewer banners)
- overspending on facilities
- injury clusters reducing results
- investment choices that fail to pay off

Loans/benefactors provide survival options with consequences.

### 14.3.2 Trigger Conditions
A stable is at risk when:
- funds drop below a solvency threshold
- obligations exceed projected income
- deterministic events damage income (when modeled)

### 14.3.3 Rescue Options
- **Traditional loan:** principal + interest + repayment schedule; failure escalates consequences.
- **Benefactor/patron:** funding with “strings” (recruitment demands, reputation shifts, influence).
- **Asset liquidation:** downgrade/sell facilities for cash (survival at long-term cost).

### 14.3.4 Deterministic Repayment
No random bankruptcy:
- repayment schedules deterministic
- income projections computed from prestige, roster tier, and banners
- failure is a predictable consequence of choices and performance

### 14.3.5 Dormant Mode Behavior
- insolvency handled via simple grace period and narrative warnings
- no instruments unless activated

---

## 14.4 Career Journals and Analytics Views

This system makes the sim legible and lovable by turning history into readable arcs.

### 14.4.1 Career Journal (Per Rikishi)
The journal is a chronological record derived from logs and events:
- debut and stable entry
- basho-by-basho results
- rank changes with contextual notes
- signature bouts (upsets, rivalry spikes, yusho races)
- injuries and comebacks
- style drift and favored kimarite evolution
- retirement and legacy outcomes

**Rule:** journals are generated deterministically; no manual writing required.

### 14.4.2 Analytics Views (Player and World)
Analytics are “truth tools”:
- win rate by stance type
- kimarite class distribution
- favored moves over time
- physique progression (current vs potential)
- injury and fatigue patterns
- stable dashboards: prestige trend, finances trend, roster pipeline

### 14.4.3 Dormant Mode Behavior
- store enough history to reconstruct later
- UI may show a minimal “History” summary (recent basho + top kimarite)

---

## 14.5 Activation Order Principle
To minimize retcons:
1) Career Journals & Analytics (consumes logs; low systemic risk)
2) Loans/Benefactors (extends economy)
3) Stable Mergers (extends closure handling)
4) Governance V1 (ties everything together; highest systemic impact)


End of Clean Canon v1.2 (Full)
