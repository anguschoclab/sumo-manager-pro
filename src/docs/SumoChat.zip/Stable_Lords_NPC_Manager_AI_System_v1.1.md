# Stable Lords — NPC Beya Manager AI System v1.1  
## Meta Drift, Adaptation, and Succession (Canonical, Verbose)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-ready  
Supersedes: NPC Beya Manager AI System v1.0  
Related Specs:
- Beya Management System v1.0
- Training System v1.0
- Rikishi Evolution System v1.0
- Combat Engine V3

---

## 1. Purpose and Design Goals

This document defines the **full lifecycle of NPC beya managers**:
- how they behave day-to-day
- how they interpret and adapt to a drifting competitive meta
- how they fail
- how they are replaced
- how retired rikishi become managers
- how identity persists across generations

Goals:
- NPC stables feel *institutional*, not disposable
- Change happens through **people**, not patches
- Meta adaptation is **imperfect, delayed, and biased**
- Succession creates eras, not resets

> NPC managers do not optimize the meta. They inherit it, misread it, and pass it on.

---

## 2. Manager as a Persistent Actor

Each NPC beya has exactly one **active Manager** at a time.

A Manager consists of:
- Profile (strategy parameters)
- Quirks (bias modifiers)
- Tenure data (years served, successes, failures)
- Origin (ex-rikishi or external appointment)
- Legacy modifiers (how they influence successors)

Managers persist until:
- retirement
- forced replacement (failure, governance)
- death (rare, narrative)
- promotion to governance role (future)

---

## 3. Manager Profile Parameters (Recap)

Each manager has deterministic traits in the range [0–1]:

### Strategic
- RiskTolerance
- Patience
- PipelineBias
- StarBias
- RecoveryBias
- IdentityRigidity
- FinanceDiscipline
- FacilityAmbition

### Talent Evaluation
- ScoutingConfidence
- UpsideChasing
- VarianceAversion
- Loyalty

### Foreign Policy
- ForeignSlotAggression
- DualCitizenPreference

These values never change for a given manager.

---

## 4. Canonical Manager Archetypes

(Profiles unchanged from v1.0; listed here for completeness)

- Talent Factory  
- Star Chaser  
- Survivor  
- Gambler  
- Traditionalist  

Each archetype defines:
- roster target range
- spending posture
- recruitment philosophy
- adaptation speed
- tolerance for decline

---

## 5. Meta Drift System (World-Level)

### 5.1 What Constitutes the Meta

Each basho, the world computes meta indicators from top divisions:

| Metric | Meaning |
|---|---|
| styleShare | Distribution of Oshi / Yotsu / Hybrid |
| kimariteClassShare | Push, Throw, Slap/Pull, Trip, Rear |
| pressureIndex | Short bouts, shove dominance |
| gripIndex | Belt dominance and grip resolution |
| injuryIndex | Injuries per 100 bouts |

These are stored historically.

---

### 5.2 Drift Detection

Two rolling windows:
- **Short**: last 2 basho (signal)
- **Long**: last 6 basho (baseline)

Drift vector:
```
drift = shortAvg − longAvg
```

Only drift above threshold is actionable.

---

## 6. Manager Interpretation of Meta

Managers do not see raw metrics.

They perceive:
- “Pushers are everywhere”
- “Our guys keep losing on the belt”
- “Injuries are climbing league-wide”

Perception is filtered by:
- ScoutingConfidence
- Patience
- IdentityRigidity
- Quirks

This creates disagreement between stables about “what’s happening.”

---

## 7. Reaction Lag and Confirmation

### 7.1 Reaction Lag Table

| Profile | Minimum Delay |
|---|---|
| Gambler | 1–2 basho |
| Star Chaser | 1–3 basho |
| Talent Factory | 3–6 basho |
| Survivor | 4–6 basho |
| Traditionalist | 4–8 basho |

---

### 7.2 Confirmation Rules

Before adaptation:
- Drift magnitude must exceed threshold
- AND local results must confirm trend

Exceptions:
- Gambler may act on short-window noise
- Traditionalist requires strong long-window confirmation

---

## 8. Adaptation Levers (Non-Training)

Managers adapt using **structural decisions**, not micromanagement.

### 8.1 Available Levers
- Recruitment bias (physique, style)
- Facility investment priority
- Roster size contraction/expansion
- Foreign-slot usage
- Focus slot allocation (defined in Training System)

---

### 8.2 Adaptation Tables

#### Pressure / Oshi Meta ↑
| Profile | Typical Response |
|---|---|
| Star Chaser | Recruit power/speed, push stars |
| Talent Factory | Shift intake heavier |
| Survivor | Minimal change |
| Traditionalist | Counter-meta throws |
| Gambler | Extreme commitment |

#### Grip / Yotsu Meta ↑
| Profile | Typical Response |
|---|---|
| Traditionalist | Advantage, little change |
| Talent Factory | Technique-heavy intake |
| Star Chaser | Chase elite belt technicians |
| Gambler | Rare specialists |

#### Injury Meta ↑
| Profile | Typical Response |
|---|---|
| Survivor | Medical investment |
| Talent Factory | Recovery facilities |
| Star Chaser | Risk collapse |
| Gambler | Double down or implode |

---

## 9. Counter-Meta Behavior

If:
- one style exceeds 55% prevalence
- AND manager has high IdentityRigidity or Contrarian quirk

Then:
- manager may intentionally pursue counter-meta identity

Counter-meta success is delayed but can define eras.

---

## 10. Failure States and Manager Evaluation

Each basho, managers are evaluated on:
- competitive results vs expectations
- financial health
- injury burden
- roster health
- prestige trend

Failure does not immediately remove managers.

---

## 11. Succession and Manager Replacement

### 11.1 Triggers for Replacement
- prolonged underperformance
- insolvency
- succession crisis (oyakata age)
- governance intervention (future)
- catastrophic scandal (future)

---

### 11.2 Replacement Sources

When replacement occurs, candidates are evaluated:

1. **Internal Ex-Rikishi**
2. **External Appointment**
3. **Caretaker Manager** (temporary)

---

## 12. Ex-Rikishi Becoming Managers

### 12.1 Eligibility

A retired rikishi may become a manager if:
- retirement age ≥ threshold
- career prestige above minimum
- no major conduct flags
- holds (or later acquires) required credentials

---

### 12.2 Trait Inheritance

Ex-rikishi managers derive traits from career:

| Career Trait | Manager Effect |
|---|---|
| Long career | Higher Patience |
| Injury-prone | Higher RecoveryBias |
| Star success | Higher StarBias |
| Journeyman | Higher PipelineBias |
| Foreign career | Higher DualCitizenPreference |

This creates *lineage memory*.

---

### 12.3 Identity Continuity

Ex-rikishi managers:
- reinforce stable identity
- resist abrupt philosophical shifts
- slow meta overreaction

They are safer, but less adaptive.

---

## 13. External Managers

External appointments:
- reset some biases
- increase volatility
- may clash with stable identity

Used when:
- no eligible internal successor
- governance forces intervention

---

## 14. Manager Legacy Effects

Departing managers leave a **legacy modifier** for successors:
- lingering identity rigidity
- cultural momentum
- staff loyalty inertia

Legacy decays over 2–4 basho.

---

## 15. AI Determinism Contract

Manager creation, decisions, adaptation, and replacement are:
- seed-based
- reproducible
- inspectable for debugging

Same world seed → same managerial history.

---

## 16. Player-Facing Readability

Players perceive:
- “This stable changed philosophy after retirement”
- “They are stuck in the past”
- “New manager, new risks”

Players never see trait numbers.

---

## 17. Canon One-Liner

> **NPC beya managers are not balance patches — they are characters whose biases, careers, and successors shape how the meta is interpreted and misinterpreted across generations.**

---

End of document.
