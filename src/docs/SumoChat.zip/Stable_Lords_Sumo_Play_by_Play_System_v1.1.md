# Stable Lords — Sumo Play-by-Play (PBP) System v1.1  
## Narrative Bout Rendering with Special Rulings & Commentary Styles (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-grade  
Supersedes: PBP System v1.0

Scope: This document defines how **live sumo Play-by-Play (PBP)** is rendered in Stable Lords, including:
- continuous narrative flow (no visible phases)
- backend fidelity to Combat Engine V3
- special ruling branches (mono-ii, torinaoshi, mizui-iri)
- commentator voice style matrix
- deterministic narrative generation

---

## 1. Core Principle (Reaffirmed)

The player experiences a bout as **live broadcast narration**:
- flowing
- ritual-aware
- culturally grounded
- emotionally legible

The engine resolves the bout discretely.
The narration does not.

---

## 2. Commentator Voice Style Matrix (NEW)

Each bout is rendered through one of three **commentary voices**.
Voice is selected deterministically by:
- era preset
- broadcaster identity
- bout importance (rank, day, stakes)

### 2.1 Voice Styles

#### Formal (Default / Traditional)
Tone:
- restrained
- precise
- respectful of ritual

Language traits:
- short declarative sentences
- minimal adjectives
- emphasis on correctness

Example:
> “A clean tachiai. He secures the belt and advances steadily.”

---

#### Dramatic (High-Stakes / Late Basho)
Tone:
- heightened
- emotional
- crowd-aware

Language traits:
- rising cadence
- exclamations used sparingly
- emphasis on turning points

Example:
> “The balance breaks! The crowd erupts as he surges forward!”

---

#### Understated (Early Basho / Regional)
Tone:
- quiet
- observational
- analytical

Language traits:
- neutral phrasing
- subtle implication
- less crowd emphasis

Example:
> “He waits. The opening comes. He takes it.”

---

### 2.2 Voice Constraints
- Voice never changes mid-bout
- Voice affects adjectives, cadence, and emphasis only
- No voice alters factual content

---

## 3. Special Ruling Narrative Branches (NEW)

Special rulings are **rare but significant**.
They must feel weighty, never procedural.

---

### 3.1 Mono-ii (Judges’ Conference)

#### Trigger
- Simultaneous touch
- Edge ambiguity
- Unclear force-out

#### Narrative Handling
- Immediate uncertainty
- Gyoji hesitation
- Judges’ entrance

Example PBP:
> “The gyoji hesitates… no call yet.”  
> “Now the shimpan are on the dohyo—this one is too close.”  
> “The crowd waits in silence.”

#### Resolution Variants
- Gunbai confirmed
- Gunbai reversed
- Torinaoshi ordered

---

### 3.2 Torinaoshi (Rematch)

#### Narrative Rules
- Treated as continuation, not reset
- Fatigue implied
- Tension escalated

Example PBP:
> “A rematch has been ordered.”  
> “Both men return—breathing heavier now.”  
> “This time, there will be no doubt.”

Rematch narration is shorter, tighter, more urgent.

---

### 3.3 Mizui-iri (Water Break)

#### Trigger
- Extended deadlock
- No decisive advantage over long duration

#### Narrative Handling
Mizui-iri is **ritualistic**, not dramatic.

Example PBP:
> “Still no movement—neither man yields.”  
> “The gyoji steps in. A water break is called.”  
> “They return to their corners, eyes never leaving the ring.”

Post-break narration emphasizes:
- stiffness
- reduced explosiveness
- subtle advantage shifts

---

## 4. Sample Bout with Special Ruling (PBP)

**Honbasho:** Nagoya Basho  
**Day:** 14  
**Division:** Makuuchi  
**Voice Style:** Dramatic

**East Ozeki — Raidenmaru**  
**West Sekiwake — Kiyonoumi**

---

> “Day Fourteen, and the tension is thick in the air. Every bout matters now.”  
> “The gyoji calls them forward. No delay.”  
> “They charge—*tachiai!* A violent collision!”  
> “Neither man gives ground—locked chest to chest!”  
> “Raidenmaru presses! Kiyonoumi resists—both at the edge!”  
> “Down they go—together!”  
> “Wait—no call!”  
> “The shimpan step in. This is too close to decide.”  
> “After discussion… a rematch!”  

**Torinaoshi**

> “They return quickly—faces tight, breathing heavy.”  
> “The charge again!”  
> “Kiyonoumi slips inside—this time he has the angle!”  
> “Raidenmaru stumbles—out!”  

**Winner:** **Kiyonoumi**  
**Kimarite:** **Yoritaoshi**

> “What a turnaround! After the rematch, it’s Kiyonoumi who prevails!”

---

## 5. Backend Fidelity (Unchanged)

Internally, the engine still resolves:
- initiative
- grip
- momentum
- fatigue
- legality of special rulings

Narrative branches are selected **after** engine resolution.

---

## 6. Determinism Guarantee

Given:
- same world seed
- same bout state

The same:
- ruling branch
- voice style
- narrative text

is generated every time.

---

## 7. Canon One-Liners (Expanded)

- “When the judges step in, the silence matters.”
- “A rematch is not a reset—it is a test.”
- “The longest bouts are remembered for what did *not* give.”

---

End of Sumo Play-by-Play System v1.1
