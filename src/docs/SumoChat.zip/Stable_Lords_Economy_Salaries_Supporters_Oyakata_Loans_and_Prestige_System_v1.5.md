# Stable Lords — Economy, Salaries, Supporters, Oyakata, Loans & Prestige System v1.5 (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-ready  
Supersedes: Economy, Salaries, Allowances, Supporters, Oyakata & Prestige System v1.4  

Scope: Defines the **complete institutional economy** of Stable Lords, extended to include:
- Deterministic **Loans & Benefactors** as insolvency rescue tools
- Explicit debt instruments and repayment logic
- Governance leverage and long-term consequences
- Clear failure escalation paths (no random bankruptcy)

This document remains the **single source of truth** for all money, debt, and prestige flows.

---

## 1. Design Goals (Extended)

In addition to prior goals, the loan/benefactor system must:
- Provide **last-resort survival paths** without trivializing failure
- Create **long-term obligations**, not free money
- Introduce **political and narrative cost** to rescue
- Be fully deterministic and forecastable
- Surface risk clearly to the player

> Rescue is never free. It merely postpones judgment.

---

## 2. When Loans & Benefactors Exist

Loans and benefactors become available only when a beya is in:
- **Critical** state (runway < 4 weeks), or
- **Insolvent** state (cash < 0)

They are never available pre-emptively.

---

## 3. Debt Instruments (Canonical Types)

### 3.1 Emergency Loan (Short-Term)

**Purpose:** Immediate liquidity to prevent collapse.

- Principal: ¥200k – ¥800k (scaled to burn rate)
- Interest: **0%**
- Term: **6 months**
- Repayment: Monthly, fixed
- Grace period: 1 month
- Provider: League-backed creditor

Restrictions:
- Recruitment frozen
- Facility upgrades locked
- Public prestige hit (minor)

Failure to repay escalates to §7.

---

### 3.2 Supporter Loan (Kōenkai-Backed)

**Purpose:** Medium-term stabilization.

- Principal: ¥500k – ¥2M
- Interest: **2–4%**
- Term: **12–24 months**
- Repayment: Monthly
- Provider: Supporters Association

Strings attached:
- Increased kōenkai influence
- Reduced autonomy in future decisions
- Governance hooks (see §5)

---

### 3.3 Benefactor Bailout (High Stakes)

**Purpose:** Prevent forced closure of prestigious stables.

- Principal: ¥2M – ¥5M
- Interest: **5–8%**
- Term: **36 months**
- Repayment: Monthly, escalating
- Provider: Individual benefactor or corporate entity

Strings:
- Strong governance leverage
- Mandatory strategic constraints
- Severe consequences on default

---

## 4. Repayment & Accounting

### 4.1 Loan Object Schema

```ts
Loan {
  id: string
  principal: number
  interestRate: number
  termMonths: number
  remainingBalance: number
  monthlyPayment: number
  providerType: "league" | "koenkai" | "benefactor"
  strings: String[]
}
```

### 4.2 Repayment Rules

- Payments deducted **monthly** from beya operating fund
- Missed payment triggers escalation immediately
- No refinancing without governance intervention

---

## 5. Benefactor “Strings” & Governance Hooks

Accepting a loan applies **binding modifiers**:

### 5.1 Typical Strings
- Forced approval on:
  - stable mergers
  - major facility changes
  - foreign-slot recruitment
- Reduced oyakata autonomy
- Mandatory reporting periods

### 5.2 Governance Influence
- Loan provider gains **soft veto power**
- Repeated bailouts increase likelihood of:
  - council intervention
  - forced succession
  - loss of kabu rights (future system)

---

## 6. Prestige & Narrative Impact

| Event | Prestige Impact |
|---|---|
| Emergency Loan | −small |
| Supporter Loan | −medium |
| Benefactor Bailout | −large |

Prestige loss affects:
- kenshō frequency
- kōenkai growth
- recruitment appeal

Narratively:
- Loans generate headlines
- Bailouts become career-defining moments

---

## 7. Failure States & Escalation (No Randomness)

### 7.1 Missed Payments

1st Miss:
- Public warning
- Increased interest (+1%)

2nd Miss:
- Forced asset sales
- Staff cuts

3rd Miss:
- Mandatory merger or closure
- Oyakata removal (governance)

---

### 7.2 Insolvency with Active Debt

Debt does not disappear on insolvency.

Resolution order:
1. Freeze spending
2. Liquidate facilities
3. Cancel kōenkai support
4. Oyakata subsidies
5. Loan escalation
6. Forced merger / closure

---

## 8. AI Behavior with Loans

AI managers:
- Treat loans as **last resort**
- Survivors accept emergency loans early
- Gamblers overextend with benefactor bailouts
- Traditionalists resist until collapse risk is unavoidable

AI evaluates:
- remaining runway
- prestige cost
- autonomy loss

---

## 9. Player UX & Warnings

UI must clearly show:
- Active loans and balances
- Monthly payment obligations
- Remaining term
- Attached strings (plain language)
- Next escalation threshold

Before accepting a loan:
- Show **worst-case scenario**
- Require explicit confirmation

No hidden consequences.

---

## 10. Determinism & Auditability

All loan events emit:
- timestamp
- principal
- provider
- repayment schedule
- applied modifiers
- balance before/after

Same seed + same decisions → same outcomes.

---

## 11. Canon One-Liners

- **On loans:**  
  > “A loan saves the stable today by selling tomorrow.”

- **On benefactors:**  
  > “When a benefactor steps in, the stable stops being yours alone.”

---

End of document.
