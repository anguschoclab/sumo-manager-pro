# Stable Lords — Economy, Salaries, Allowances & Prestige System v1.2 (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-ready  
Supersedes: Economy, Salaries & Prestige System v1.1  
Scope: Defines the **full economic reality** of Stable Lords, aligned with canonical rank salary conventions:
- **Sekitori salaries are monthly** (realistic)
- Lower divisions receive **allowances** (not salary)
- Kenshō banner values and splits are realistic
- Beya operating economy, prestige, awards→prestige, retirement funds, and insolvency are fully specified

This document is the **single authoritative source** for money, salary/allowance cadence, and prestige math.

---

## 1. Design Goals

The economy must:
- Feel grounded in **real sumo financial structure**
- Support beya operations as a **budgeting game**, not an exploit
- Reward success via **rank stability and sponsor attention**
- Create meaningful long-horizon choices (staff, facilities, recruitment)
- Be deterministic and auditable
- Integrate with:
  - Banzuke, Scheduling & Awards System
  - Beya Management System
  - Training System
  - NPC Manager AI System
  - Governance & Kabu (future)

> Rank pays stability. Banners pay fame. Beya finances pay survival.

---

## 2. Currency & Cadence

- Currency: **¥** (yen-equivalent)
- Default: no inflation
- Time base:
  - **Weekly**: beya operating costs, some stipends
  - **Monthly**: sekitori salaries + lower-division allowances
  - **Per-bout**: kenshō settlement
  - **Basho-end**: awards, promotions, prestige settlement

Implementation note:
- If the sim ticks weekly, monthly salary is paid as **one lump at month boundary** or prorated deterministically (choose one; both are deterministic).

---

## 3. Economic Actors & Accounts

### 3.1 Accounts (minimum)
- `LeagueTreasury` (abstract, infinite for salary)
- `BeyaOperatingFund` (per beya, cash on hand)
- `RikishiCash` (per rikishi, liquid)
- `RikishiRetirementFund` (per rikishi, locked)

### 3.2 Ownership
- **Salaries/allowances are league-paid**, not beya-paid (realistic).
- **Beya lives on** kenshō share + optional stipends + (future) benefactors.

---

## 4. Rank-Based Pay: Monthly Salary vs Allowance

This section aligns with the canonical rank table approach (e.g., `RANK_HIERARCHY.salary` as monthly salary).

### 4.1 Sekitori Monthly Salaries (Paid Ranks: Jūryō+)

Salaries below are **monthly**:

| Rank Tier | Monthly Salary |
|---|---:|
| Yokozuna | ¥3,000,000 |
| Ōzeki | ¥2,500,000 |
| Sekiwake | ¥1,800,000 |
| Komusubi | ¥1,700,000 *(recommended; may be set = Sekiwake if desired)* |
| Maegashira (all) | ¥1,400,000 *(flat by default; optional banding)* |
| Jūryō | ¥1,100,000 |

Notes:
- For simplicity and UI clarity, Maegashira may be flat. If desired, you can band M1–5 higher and M11–17 lower, but **do not mix both without updating rank metadata**.

### 4.2 Non-Sekitori Allowances (Unpaid Ranks: Makushita and below)

Lower divisions receive a small **monthly allowance** (not salary). This reflects support without creating wealth.

| Division | Monthly Allowance |
|---|---:|
| Makushita | ¥150,000 |
| Sandanme | ¥90,000 |
| Jonidan | ¥55,000 |
| Jonokuchi | ¥35,000 |

These are intentionally modest and keep lower divisions financially constrained.

### 4.3 Pay Properties
- Paid monthly while active (including injury absence unless retired)
- Adjusts after new banzuke is published
- Does not directly change beya operating cash

---

## 5. Kenshō Banners (Performance Income)

### 5.1 Banner Value (Realistic)
- Value per banner: **¥70,000**

### 5.2 Split (Canonical)
- **50%** to winning rikishi (liquid + retirement contribution rules apply)
- **50%** to the rikishi’s **beya operating fund**

### 5.3 Kenshō Cadence
- Settled **immediately per bout** (post-result)
- Logged as an economic event

### 5.4 Banner Count Determination (Deterministic)
Each bout has a deterministic banner count based on:
- combined prestige (rikishi + beya)
- day importance (late basho higher)
- rank band (sanyaku bouts attract more)
- contention impact (yusho race)

The exact banner count formula is tunable, but must:
- be monotonic with prestige/importance
- have diminishing returns
- produce a realistic distribution (many 0–1, some high)

---

## 6. Awards → Prestige → Income Loop

### 6.1 Awards Grant Prestige (Default)
Sanshō and trophies grant **prestige** (see §7), not direct cash, by default.

Optional cash bonuses exist as a tuning layer, but default is prestige-only to prevent runaway.

### 6.2 Why This Matters
- Awards increase future kenshō availability by raising prestige
- Awards create secondary goals and career narrative value

---

## 7. Prestige System (Rikishi + Beya)

### 7.1 What Prestige Does
Prestige drives:
- sponsor attraction (kenshō frequency)
- recruitment quality bias (worldgen + scouting)
- narrative prominence
- AI valuation of “success”

Prestige is stored at:
- `rikishiPrestige`
- `beyaPrestige`

### 7.2 Prestige Gain (Illustrative)
| Event | Rikishi | Beya |
|---|---:|---:|
| Bout win | +small | +tiny |
| Upset win | +medium | +small |
| Sanshō | +large | +medium |
| Yūshō | +very large | +large |
| Promotion to Ōzeki | +huge | +huge |
| Promotion to Yokozuna | +massive | +massive |

### 7.3 Prestige Decay
Cadence: **per basho**
- Rikishi: ~2–4% decay
- Beya: ~1–2% decay
- Floors prevent total collapse

### 7.4 Prestige → Kenshō Multiplier (Diminishing Returns)
Use a logarithmic multiplier:
```
kenshoScalar = 1 + log10(1 + prestige / K)
```
(K is a global tuning constant)

---

## 8. Beya Operating Economy (How It Supports Running a Stable)

Beya cash supports:
- food, housing, daily operations
- staff payroll
- facility upkeep
- recruitment fees
- emergency costs

### 8.1 Weekly Operating Costs (Canonical)
| Expense | Formula |
|---|---|
| Wrestlers | ¥2,000 × roster size |
| Staff | ¥6,000 × staff count |
| Facilities | ¥1,000 × total facility levels |

### 8.2 Capital Costs (Recap)
- Recruiting fees
- Facility upgrades
- Emergency medical events

### 8.3 Why Beya Needs Kenshō
Because salaries are league-paid, **kenshō share is the main growth engine** and the primary way to fund:
- better facilities
- better staff
- sustainable pipelines

This mirrors real-world “stars subsidize the stable.”

---

## 9. Retirement Funds

### 9.1 Funding Sources
Retirement fund contributions are deterministic:
- **Kenshō winnings**: 30% diverted automatically
- **Monthly salary/allowance**: 10% diverted automatically

### 9.2 Locked Funds
- Not accessible mid-career
- Builds post-career security and future roles

### 9.3 Uses at Retirement (Forward-Compatible)
- cash payout
- coaching certification fees (if used)
- kabu acquisition down payment (future governance)
- stable succession buy-in (future)

---

## 10. Solvency, Insolvency & Deterministic Interventions

### 10.1 Runway Calculation
```
runwayWeeks = beyaCash / weeklyBurn
```

### 10.2 Solvency States
| State | Condition |
|---|---|
| Healthy | ≥ 8 weeks runway |
| Stressed | < 8 weeks |
| Critical | < 4 weeks |
| Insolvent | cash < 0 |

### 10.3 Automatic Rules
| State | Effects |
|---|---|
| Stressed | recruitment freeze (default) |
| Critical | upgrade lock + strong warnings |
| Insolvent | forced liquidation sequence |

### 10.4 Insolvent Resolution Order
1. Freeze spending
2. Sell facility levels (downshift)
3. Release staff
4. Forced retirements (lowest prestige / oldest first)
5. Closure or merger (when governance active)

No randomness. Always explainable.

---

## 11. AI Behavior With This Economy

AI managers use:
- runway weeks
- kenshō volatility expectations
- prestige trends

Profile differences:
- Survivor targets ≥10 weeks runway
- Gambler may accept 2–3 weeks runway
- Talent Factory invests steadily in pipeline facilities
- Star Chaser spikes spending around contention windows

AI does not “know the future”; it responds to trends and cash buffers.

---

## 12. Player UX Rules

Players should always see:
- stable cash
- weekly burn and runway weeks
- income breakdown (kenshō share, stipends)
- salary/allowance tier for each rikishi
- prestige trends and award history

Players should not see:
- internal multipliers
- exact decay formulas
- AI evaluation scores

---

## 13. Determinism & Auditability

Every economic event must emit:
- timestamp (week/day)
- actor (rikishi/beya)
- source type (salary, allowance, kenshō, cost, upgrade)
- amount
- balance before/after
- reference IDs (basho/day/bout)

Replays must be identical.

---

## 14. Canon One-Liner

> **Stable Lords’ economy mirrors sumo: the league pays rank, sponsors pay stars, and a beya survives only if it turns prestige into sustainable operations.**

---

End of document.
