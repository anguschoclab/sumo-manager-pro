# Stable Lords — Sumo Play‑by‑Play (PBP) System v1.0  
## Narrative Bout Rendering with Engine‑Faithful Resolution (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation‑grade  
Scope: This document defines how **live sumo Play‑by‑Play (PBP)** is rendered in Stable Lords, blending:
- authentic broadcast‑style commentary
- ritual and cultural context
- narrative‑first presentation
- strict fidelity to Combat Engine V3 on the backend

The player experiences a **continuous narrative flow**.  
The engine still resolves bouts in discrete phases.

If there is conflict between mechanical clarity and narrative flow, **narrative flow wins on the surface**.

---

## 1. Design Intent

PBP exists to:
- make very short bouts feel dramatic and legible
- teach the player *how* sumo works without tooltips
- communicate momentum, balance, and pressure through language
- preserve authenticity of Japanese sumo broadcasts

> The bout should feel remembered, not logged.

---

## 2. Narrative Flow Rules (Player‑Facing)

### 2.1 No Phase Headings
The player **never sees**:
- “Tachiai Phase”
- “Momentum Phase”
- “Finish Phase”

Instead, the bout reads as a **single unfolding moment**, like live commentary.

---

### 2.2 Language Priorities
PBP language should emphasize:
1. **Position** (center, drifting, edge)
2. **Balance** (stable, off‑center, scrambling)
3. **Intent** (pressing, waiting, adjusting)
4. **Turning points** (hesitation, grip found, reset failed)

Avoid:
- numbers
- percentages
- explicit stat references

---

### 2.3 Ritual & Authority
Every bout must acknowledge:
- the dohyo
- the gyoji
- the formality of the contest

This grounds even chaotic bouts in tradition.

---

## 3. Canonical PBP Elements

A complete PBP rendering may include:

- pre‑bout context (rank, stakes)
- shikiri tension
- tachiai description
- evolving control
- decisive action
- gyoji decision
- short post‑bout framing

Not all elements are required for every bout.

---

## 4. Sample Live PBP Bout (Player‑Facing)

**Honbasho:** Kyushu Basho  
**Day:** 10  
**Division:** Makuuchi  
**Dohyo:** Fukuoka

**East Maegashira 1 — Kiryuzan**  
**West Sekiwake — Aonishiki**

---

> *“An important bout here on Day Ten. Sekiwake Aonishiki needs to keep pace in the sanyaku ranks, but Kiryuzan has been dangerous from the upper maegashira.”*

> *“Both men step onto the dohyo. The gyoji moves between them, fan held high.”*

> *“They crouch at the shikiri‑sen… neither willing to blink.”*

> *“The gyoji drops his fan—*tachiai!*”*

> *“A fierce collision at the center of the ring! Aonishiki surges forward immediately, trying to impose his power!”*

> *“Kiryuzan gives ground but stays composed, heels skimming the clay as he absorbs the pressure.”*

> *“Aonishiki presses again—hard—but the push stalls! Kiryuzan has settled his base!”*

> *“Now a grip! Kiryuzan gets inside on the belt—Aonishiki twists, trying to shake him free!”*

> *“They drift toward the west side… the crowd senses the shift!”*

> *“Aonishiki tries to reset his feet—just a moment too late!”*

> *“Kiryuzan stays tight, hips low, driving forward!”*

> *“At the straw—Aonishiki has no space!”*

> *“Out! Gunbai raised—**Kiryuzan wins!**”*

**Kimarite:** **Yorikiri**

> *“A patient, powerful yorikiri from Kiryuzan. He survived the initial charge and took control when it mattered.”*

---

## 5. Post‑Bout Narrative Hooks

Immediately after the bout, optional short hooks may appear:

- **Rank Pressure:**  
  *“That result puts real pressure on Aonishiki with only five days remaining.”*

- **Rivalry Seed:**  
  *“These two have split their meetings this year—this story may not be finished.”*

- **Form Signal:**  
  *“Kiryuzan’s composure has been a theme this tournament.”*

---

## 6. Backend Resolution (Hidden, Engine‑Facing)

⚠️ **This section is never shown to the player.**  
It exists to ensure PBP remains faithful to Combat Engine V3.

### 6.1 Internal Phase Mapping
While the narrative flows continuously, the engine resolves:

1. Tachiai initiative
2. Stance & grip resolution
3. Momentum ticks (fatigue, balance)
4. Position drift
5. Finisher window
6. Counter check
7. Outcome & kimarite selection

Each narrative sentence is mapped to one or more internal events.

---

### 6.2 Deterministic Kimarite Selection
Kimarite is selected from the filtered legal set based on:
- stance
- grip state
- balance
- position
- fatigue deltas

Narrative wording adapts to the selected kimarite, not vice versa.

---

### 6.3 Gyoji Call Logic
- Clear wins → immediate gunbai
- Edge ambiguity → delayed phrasing
- Rare mono‑ii → special narrative branch

---

## 7. Narrative Templates (Illustrative)

### Push‑Out Finish
> *“He never lets him settle—straight back and out!”*

### Counter Throw
> *“Just as the pressure peaks, he turns it against him!”*

### Scramble Finish
> *“Both men lose balance—one touch decides it!”*

Templates are selected deterministically and rotated to avoid repetition.

---

## 8. Integration with Other Systems

- **Scouting:** repeated phrasing reinforces tendencies  
- **Rivalries:** tone escalates with history  
- **Journals:** key sentences become career entries  
- **Media:** headlines borrow phrasing from decisive moments  

---

## 9. Determinism Contract

Given:
- same world seed
- same bout inputs

The same PBP text is generated.

No random adjectives.  
No RNG flavor.

---

## 10. Canon One‑Liners

- *“The bout lasts seconds. The memory lasts years.”*
- *“What matters is not how long it took, but who broke first.”*
- *“The gyoji does not explain. He decides.”*

---

End of Sumo Play‑by‑Play System v1.0
