# Stable Lords — Economy, Salaries, Allowances, Supporters & Prestige System v1.3 (Canonical)

Date: 2026-01-06  
Status: Canonical, verbose, implementation-ready  
Supersedes: Economy, Salaries, Allowances & Prestige System v1.2  

Scope: Defines the **complete economic reality** of Stable Lords, aligned with real-world sumo:
- Monthly sekitori salaries (league-paid)
- Monthly allowances for lower divisions
- Kenshō banner economics
- **Kōenkai / Supporters Associations**
- **Oyakata personal subsidies**
- Beya operating budgets, prestige, retirement funds, and insolvency

This document is the **single authoritative source of truth** for money and prestige.

---

## 1. Design Goals

The economy must:
- Reflect **realistic sumo institutional finance**
- Make beya survival uncertain but explainable
- Reward prestige, stability, and social capital
- Avoid runaway snowballing
- Be deterministic and auditable
- Integrate with:
  - Banzuke, Scheduling & Awards
  - Beya Management
  - Training
  - NPC Manager AI
  - Governance & Kabu (future)

> Rank pays the wrestler. Supporters keep the stable alive.

---

## 2. Currency & Cadence

- Currency: ¥ (yen-equivalent)
- No inflation by default
- Cadence:
  - **Weekly**: beya operating costs
  - **Monthly**: salaries, allowances, supporter contributions
  - **Per-bout**: kenshō settlement
  - **Basho-end**: awards, promotions, prestige updates

---

## 3. Economic Accounts

### 3.1 Accounts
- LeagueTreasury (abstract)
- BeyaOperatingFund
- RikishiCash
- RikishiRetirementFund
- OyakataPersonalFund (NPC + player)

---

## 4. Rank-Based Pay (League-Funded)

### 4.1 Sekitori Monthly Salaries

| Rank | Monthly Salary |
|---|---:|
| Yokozuna | ¥3,000,000 |
| Ōzeki | ¥2,500,000 |
| Sekiwake | ¥1,800,000 |
| Komusubi | ¥1,700,000 |
| Maegashira | ¥1,400,000 |
| Jūryō | ¥1,100,000 |

Paid monthly. Not part of beya budget.

---

### 4.2 Non-Sekitori Allowances

| Division | Monthly Allowance |
|---|---:|
| Makushita | ¥150,000 |
| Sandanme | ¥90,000 |
| Jonidan | ¥55,000 |
| Jonokuchi | ¥35,000 |

League-funded, modest by design.

---

## 5. Kenshō Banners (Performance Income)

- ¥70,000 per banner
- 50% rikishi / 50% beya
- Paid immediately per bout
- Primary scalable income source for beya

---

## 6. Kōenkai / Supporters Association System (NEW)

### 6.1 What a Kōenkai Is

Each beya may have **0–1 active Kōenkai**, representing:
- wealthy fans
- corporations
- alumni
- regional or cultural backing

A Kōenkai is **not guaranteed**.

---

### 6.2 Kōenkai Strength Levels

| Level | Monthly Contribution | Description |
|---|---:|---|
| None | ¥0 | No organized support |
| Weak | ¥50,000 | Small local donors |
| Moderate | ¥150,000 | Stable fan base |
| Strong | ¥400,000 | Corporate/elite backing |
| Powerful | ¥800,000 | Rare, prestigious support |

Paid **monthly** into the beya operating fund.

---

### 6.3 Kōenkai Growth & Decay

Kōenkai strength evolves deterministically based on:
- beya prestige trend
- presence of sekitori
- yūshō and sanshō frequency
- scandal or insolvency events

Decay occurs if:
- long sekitori drought
- repeated insolvency
- oyakata retirement without succession clarity

---

### 6.4 Loss of Kōenkai

If prestige drops sharply or scandals occur:
- Kōenkai may downgrade or dissolve
- This is deterministic, not random
- Loss is narratively emphasized

---

## 7. Oyakata Personal Subsidies (NEW)

### 7.1 Purpose

Oyakata often personally subsidize stables using:
- career savings
- elder stock income
- external work

This system models that reality.

---

### 7.2 Oyakata Personal Fund

Each oyakata has:
- a personal cash pool
- risk tolerance (derived from manager profile)
- willingness-to-subsidize threshold

---

### 7.3 Subsidy Rules

- Subsidies are **optional but deterministic**
- Triggered when beya enters **Stressed** or **Critical**
- Amount capped per month (e.g., ¥100k–¥500k)
- Personal funds are finite

Subsidies do **not** increase prestige.

---

### 7.4 Long-Term Consequences

Heavy reliance on subsidies:
- weakens succession prospects
- reduces ability to acquire kabu (future)
- increases collapse risk upon retirement

---

## 8. Prestige System (Recap)

Prestige affects:
- kenshō frequency
- kōenkai strength
- recruitment quality
- narrative prominence

Decay applies per basho with floors.

---

## 9. Beya Operating Economy

### 9.1 Weekly Costs

| Expense | Formula |
|---|---|
| Wrestlers | ¥2,000 × roster |
| Staff | ¥6,000 × staff |
| Facilities | ¥1,000 × facility levels |

---

### 9.2 Capital Costs
- recruitment
- upgrades
- emergency medical events

---

## 10. Retirement Funds (Recap)

- 30% of kenshō winnings
- 10% of salary/allowance
- Locked until retirement
- Used for coaching, kabu, succession (future)

---

## 11. Solvency & Insolvency

### 11.1 States

| State | Condition |
|---|---|
| Healthy | ≥ 8 weeks runway |
| Stressed | < 8 weeks |
| Critical | < 4 weeks |
| Insolvent | cash < 0 |

---

### 11.2 Resolution Order
1. Freeze spending
2. Sell facilities
3. Release staff
4. Forced retirements
5. Kōenkai downgrade/loss
6. Oyakata subsidies (if available)
7. Closure or merger (governance)

---

## 12. AI Behavior

AI managers:
- account for kōenkai income stability
- value prestige more when kōenkai is weak
- differ in subsidy willingness:
  - Survivor: early subsidies
  - Gambler: late subsidies
  - Traditionalist: reluctant

---

## 13. Player UX Rules

Players see:
- salary/allowance tiers
- kenshō income
- kōenkai status & contribution
- subsidy events (clearly marked)
- runway weeks

Players never see:
- hidden multipliers
- AI thresholds

---

## 14. Canon One-Liner

> **In Stable Lords, a beya survives not on salaries, but on stars, supporters, and the oyakata’s willingness to sacrifice for the institution.**

---

End of document.
